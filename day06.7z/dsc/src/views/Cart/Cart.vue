<!--  -->
<template>
    <div class="cart-box" @click="jiazai">
        <ul class="cart-goods" v-if="nullshow">
            <li v-for="items in nullshow" :key="items.ru_id">
                <div class="shop">
                    <label
                        class="shopcheck"
                        @click="shopcheck(items.isselected, items.ru_id)"
                    >
                        <input type="checkbox" :checked="items.isselected" />
                        <span class="iconfont icon-danxuankuang nocheck"></span>
                        <span
                            class="iconfont icon-danxuankuangxuanzhong ischeck"
                        ></span>
                    </label>
                    <h3>{{ items.shop_name }}</h3>
                </div>
                <ul class="goods">
                    <li v-for="goods in items.goods" :key="goods.good_id">
                        <label
                            class="good_check"
                            @click="
                                goodscheck(
                                    items.ru_id,
                                    goods.good_id,
                                    goods.isselected
                                )
                            "
                        >
                            <input
                                type="checkbox"
                                :checked="goods.isselected"
                            />
                            <span
                                class="iconfont icon-danxuankuang nocheck"
                            ></span>
                            <span
                                class="iconfont icon-danxuankuangxuanzhong ischeck"
                            ></span>
                        </label>
                        <div class="goods_msgbox">
                            <router-link
                                :to="'/goodsdetall/' + goods.good_id"
                                tag="img"
                                :src="goods.good_img"
                                alt=""
                            />
                            <div class="goods_msg">
                                <router-link
                                    :to="'/goodsdetall/' + goods.good_id"
                                    tag="p"
                                    class="goods_title"
                                >
                                    {{ goods.good_title }}
                                </router-link>
                                <div class="goods_san">
                                    <span class="goods_price"
                                        >￥{{ goods.good_price }}</span
                                    >
                                    <ul>
                                        <li>
                                            <button
                                                @click.stop="
                                                    countdown(
                                                        items.ru_id,
                                                        goods.good_id
                                                    )
                                                "
                                            >
                                                -
                                            </button>
                                            <input
                                                ref="countref"
                                                type="text"
                                                v-model="goods.value"
                                                @input="
                                                    couninput(
                                                        items.ru_id,
                                                        goods.good_id
                                                    )
                                                "
                                            />
                                            <button
                                                @click.stop="
                                                    countup(
                                                        items.ru_id,
                                                        goods.good_id
                                                    )
                                                "
                                            >
                                                +
                                            </button>
                                        </li>
                                        <li
                                            class="iconfont icon-shoucang1"
                                        ></li>
                                        <li class="iconfont icon-shanchu"></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </li>
                </ul>
            </li>
        </ul>
        <div class="cart-goods-null" v-if="!nullshow">
            <img src="../../assets/images/cart-empty.png" alt="" />
            <p>您的购物车还是空空的，快去逛逛吧!</p>
            <div><button>去逛逛</button><button>看看关注</button></div>
        </div>
        <div class="cart-all" v-if="nullshow">
            <label class="check-all" @click="allcheck">
                <input type="checkbox" :checked="allchecked" />
                <span class="iconfont icon-danxuankuang nocheck"></span>
                <span
                    class="iconfont icon-danxuankuangxuanzhong ischeck"
                ></span>
                <i>
                    全选
                </i>
            </label>
            <div class="cartallconten">
                <ul class="priceall">
                    <li>
                        合计&nbsp;:&nbsp;<span>{{
                            parseInt(computcount[0])
                        }}</span>
                    </li>
                    <li>(不含运费，已节省￥{{ 1200 }})</li>
                </ul>
                <div class="settlement">去结算({{ computcount[1] }})</div>
            </div>
        </div>
        <div class="cart-guess">
            <div class="goodguess">
                ——————
                <span>猜你喜欢</span>
                ——————
            </div>
            <div>
                <Recommend :rdata="cartguess" @getrecommend="getrecommend" />
            </div>
        </div>
        <Footer />
    </div>
</template>

<script>
//这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
//例如：import 《组件名称》 from '《组件路径》';
import Footer from "@/components/Footer";
import Recommend from "../Home/components/Recommend";
export default {
    //import引入的组件需要注入到对象中才能使用
    components: {
        Recommend,
        Footer,
    },
    data() {
        //这里存放数据
        return {};
    },
    //监听属性 类似于data概念
    computed: {
        cartguess() {
            return this.$store.state.goodguessdata;
        },
        nullshow() {
            return this.$store.state.cartdata;
        },
        allchecked() {
            return this.$store.state.allchecked;
        },
        computcount() {
            return this.$store.state.computcount;
        },
    },
    //监控data中的数据变化
    watch: {},
    //方法集合
    methods: {
        jiazai() {
            this.$store.commit("tocartdata");
        },
        getrecommend() {
            this.$store.dispatch("actgoodguess", { page: 1, siez: 10 });
        },
        shopcheck(status, id) {
            let data = JSON.parse(localStorage.getItem("goods"));
            let cart = data.find((items) => {
                return items.ru_id == id;
            });
            if (status) {
                cart.isselected = false;
                for (let i = 0; i < cart.goods.length; i++) {
                    cart.goods[i].isselected = false;
                }
                localStorage.setItem("allchecked", false);
            } else {
                cart.isselected = true;
                for (let i = 0; i < cart.goods.length; i++) {
                    cart.goods[i].isselected = true;
                }
                this.pdstatus();
            }
            this.$store.commit("tocomputcount");
            localStorage.setItem("goods", JSON.stringify(data));
        },
        goodscheck(shopid, goodid, status) {
            let data = JSON.parse(localStorage.getItem("goods"));
            let cart = data.find((items) => {
                return items.ru_id == shopid;
            });
            let goods = cart.goods.find((items) => {
                return items.good_id == goodid;
            });
            if (status) {
                cart.isselected = goods.isselected = false;
                localStorage.setItem("allchecked", false);
            } else {
                goods.isselected = true;
                let goodsstatus = cart.goods.every((items) => {
                    return items.isselected == true;
                });
                if (goodsstatus) {
                    cart.isselected = true;
                }
                this.pdstatus();
            }
            this.$store.commit("tocomputcount");
            localStorage.setItem("goods", JSON.stringify(data));
        },
        allcheck() {
            let data = JSON.parse(localStorage.getItem("goods"));
            if (JSON.parse(this.allchecked)) {
                localStorage.setItem("allchecked", false);
                for (let i = 0; i < data.length; i++) {
                    data[i].isselected = false;
                    for (let j = 0; j < data[i].goods.length; j++) {
                        data[i].goods[j].isselected = false;
                    }
                }
            } else {
                localStorage.setItem("allchecked", true);
                for (let i = 0; i < data.length; i++) {
                    data[i].isselected = true;
                    for (let j = 0; j < data[i].goods.length; j++) {
                        data[i].goods[j].isselected = true;
                    }
                }
            }
            this.$store.commit("tocomputcount");
            localStorage.setItem("goods", JSON.stringify(data));
        },
        pdstatus() {
            let data = JSON.parse(localStorage.getItem("goods"));
            let st = data.every((items) => {
                return items.isselected == true;
            });
            if (st) {
                localStorage.setItem("allchecked", true);
            }
        },
        couninput(ru_id, good_id) {
            let count = event.target.value;
            this.commitvalue(ru_id, good_id, count);
        },
        countup(ru_id, good_id) {
            event.target.parentElement.children[1].focus();
            event.target.parentElement.children[1].value++;
            let count = event.target.parentElement.children[1].value;
            this.commitvalue(ru_id, good_id, count);
        },
        countdown(ru_id, good_id) {
            event.target.parentElement.children[1].focus();
            event.target.parentElement.children[1].value--;
            let count = event.target.parentElement.children[1].value;
            this.commitvalue(ru_id, good_id, count);
        },
        commitvalue(id1, id2, count) {
            let data = JSON.parse(localStorage.getItem("goods"));
            let ru = data.find((items) => {
                return items.ru_id == id1;
            });
            let goods = ru.goods.find((items) => {
                return items.good_id == id2;
            });
            goods.value = parseInt(count);
            localStorage.setItem("goods", JSON.stringify(data));
        },
    },
    beforeCreate() {}, //生命周期 - 创建之前
    //生命周期 - 创建完成（可以访问当前this实例）
    created() {},
    beforeMount() {}, //生命周期 - 挂载之前
    //生命周期 - 挂载完成（可以访问DOM元素）
    mounted() {
        this.getrecommend();
        this.$store.commit("tocartdata");
        this.$store.commit("toallchecked");
        this.$store.commit("tocomputcount");

        window.scroll(0, 0);
    },
    beforeUpdate() {}, //生命周期 - 更新之前
    updated() {}, //生命周期 - 更新之后
    beforeDestroy() {}, //生命周期 - 销毁之前
    destroyed() {}, //生命周期 - 销毁完成
    activated() {}, //如果页面有keep-alive缓存功能，这个函数会触发
};
</script>
<style lang="less">
.cart-box {
    width: 100%;
    padding: 1rem 1rem 6rem;
    background: rgba(0, 0, 0, 0.05);
    .cart-goods-null {
        width: 100%;
        height: 25.5rem;
        background: #fff;
        border-radius: 1.2rem;
        display: flex;
        flex-direction: column;
        align-items: center;
        font-size: 1.4rem;
        img {
            width: 10rem;
            margin-top: 4rem;
        }
        p {
            margin: 1rem 0rem;
        }
        div {
            button {
                padding: 0.6rem 1.2rem;
                background: #fff;
                border: 1px solid rgba(0, 0, 0, 0.1);
                border-radius: 0.3rem;
                margin: 0rem 0.5rem;
            }
        }
    }
    .cart-goods {
        width: 100%;
        li {
            width: 100%;
            .shop {
                width: 100%;
                display: flex;
                align-items: center;
                margin-top: 1rem;

                label {
                    height: 2rem;
                    margin-right: 1.2rem;
                    line-height: 2rem;
                }
                h3 {
                    font-size: 1.8rem;
                }
                .shopcheck > [type="checkbox"]:checked ~ .nocheck {
                    display: none;
                }

                .shopcheck > [type="checkbox"]:checked ~ .ischeck {
                    display: block;
                }
            }
            .goods {
                li {
                    width: 100%;
                    display: flex;
                    align-items: center;
                    .good_check {
                        width: 8%;
                        [type="checkbox"]:checked ~ .nocheck {
                            display: none;
                        }

                        [type="checkbox"]:checked ~ .ischeck {
                            display: block;
                        }
                    }
                    .goods_msgbox {
                        width: 92%;
                        display: flex;
                        background: #fff;
                        padding: 1rem;
                        border-radius: 0.2rem;
                        margin-top: 1.2rem;
                        > img {
                            width: 8rem;
                            height: 8rem;
                        }
                        .goods_msg {
                            display: flex;
                            flex-direction: column;
                            align-items: center;
                            justify-content: space-between;
                            .goods_title {
                                width: 90%;
                                font-size: 1.3rem;
                                overflow: hidden;
                                display: -webkit-box;
                                -webkit-box-orient: vertical;
                                -webkit-line-clamp: 2;
                            }
                            .goods_san {
                                width: 90%;
                                display: flex;
                                justify-content: space-between;
                                .goods_price {
                                    color: orangered;
                                    font-size: 1.6rem;
                                }
                                > ul {
                                    display: flex;
                                    li {
                                        margin: 0 0.2rem;
                                        input {
                                            width: 3rem;
                                            height: 2rem;
                                            border: 1px solid #cccccc40;
                                            text-align: center;
                                        }
                                        button {
                                            width: 2rem;
                                            height: 2rem;
                                            border: 1px solid #cccccc40;
                                        }
                                    }
                                    .iconfont {
                                        font-size: 1.6rem;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    .cart-guess {
        .goodguess {
            margin: 1.4rem 0rem;
            text-align: center;
            span {
                font-size: 1.6rem;
            }
        }
    }
    .cart-all {
        width: 100%;
        position: fixed;
        bottom: 5rem;
        left: 0;
        background: rgb(255, 255, 255);
        z-index: 99;
        display: flex;
        align-items: center;
        .check-all {
            width: 20%;
            i {
                font-style: normal;
                font-size: 1.6rem;
            }
        }
        .check-all > [type="checkbox"]:checked ~ .nocheck {
            display: none;
        }
        .check-all > [type="checkbox"]:checked ~ .ischeck {
            display: inline-block;
        }
        .cartallconten {
            width: 80%;
            height: 4.5rem;
            display: flex;
            justify-content: flex-end;
            .priceall {
                margin-right: 1rem;
                li:first-of-type {
                    text-align: right;
                    font-size: 1.4rem;
                    span {
                        color: orangered;
                        font-size: 1.6rem;
                        font-weight: bold;
                    }
                    span::before {
                        content: "￥";
                        font-size: 1.2rem;
                    }
                    span::after {
                        content: ".00";
                        font-size: 1.2rem;
                    }
                }
                li:last-of-type {
                    color: #ccc;
                    margin-top: 0.5rem;
                }
            }
            .settlement {
                width: 35%;
                text-align: center;
                line-height: 4.5rem;
                background: orangered;
                font-size: 1.3rem;
                color: #fff;
            }
        }
    }
}
[type="checkbox"] {
    display: none;
}
.ischeck,
.nocheck {
    font-size: 2rem;
}
.ischeck {
    color: orangered;
    display: none;
}
</style>
