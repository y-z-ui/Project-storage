<!--  -->
<template>
    <div class="home">
        <div class="rotation-bgc">
            <HomeHeader />
        </div>
        <div class="content">
            <router-view></router-view>
        </div>
        <Footer />
    </div>
</template>

<script>
//这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
//例如：import 《组件名称》 from '《组件路径》';
import Footer from "@/components/Footer";
import HomeHeader from "./components/HomeHeader";
export default {
    //import引入的组件需要注入到对象中才能使用
    components: {
        Footer,
        HomeHeader,
    },
    data() {
        //这里存放数据
        return {};
    },
    //监听属性 类似于data概念
    computed: {
        unlogin() {
            return this.$store.state.unlogin;
        },
    },
    //监控data中的数据变化
    watch: {
        unlogin() {
            if (!this.unlogin.token) {
                this.$router.push("/administrator/1");
            }
        },
    },
    //方法集合
    methods: {
        windowscroll() {
            window.onscroll = function() {
                // console.log(window.pageYOffset);
                if (window.pageYOffset >= 210) {
                    document.querySelector(".rotation-bgc").style.position =
                        "fixed";
                } else {
                    document.querySelector(".rotation-bgc").style.position =
                        "absolute";
                }
            };
        },
    },
    beforeCreate() {}, //生命周期 - 创建之前
    //生命周期 - 创建完成（可以访问当前this实例）
    created() {},
    beforeMount() {}, //生命周期 - 挂载之前
    //生命周期 - 挂载完成（可以访问DOM元素）
    mounted() {
        this.windowscroll();
    },
    beforeUpdate() {}, //生命周期 - 更新之前
    updated() {}, //生命周期 - 更新之后
    beforeDestroy() {}, //生命周期 - 销毁之前
    destroyed() {}, //生命周期 - 销毁完成
    activated() {}, //如果页面有keep-alive缓存功能，这个函数会触发
};
</script>
<style lang="less">
.rotation-bgc {
    transition: all 0.5s ease;
    background: red;
    width: 100%;
    position: absolute;
    top: 0;
    left: 0;
    z-index: 1000;
}
.home {
    padding-bottom: 4.5rem;
    > .content {
        margin-top: 9.3rem;
    }
}
</style>
