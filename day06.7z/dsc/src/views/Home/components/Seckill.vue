<!-- 限时秒杀 -->
<template>
    <div class="seckill">
        <div class="seckilltitle">
            <img
                src="https://x.dscmall.cn/storage/data/gallery_album/177/original_img/177_P_1597978468241.png?imageView2/2/format/webp"
                alt=""
            />
            <div class="seckilltime">
                距离结束还有:<span>{{ hours }}</span
                >:<span>{{ minute }}</span
                >:<span>{{ second }}</span>
            </div>
        </div>
        <div class="seckill-box">
            <ul>
                <li
                    v-for="(items, index) in timelist"
                    :key="index"
                    @click="seckillactive(index)"
                    :class="{ seckillactive: seckillflag == index }"
                >
                    <p>{{ items.title }}</p>
                    <span>{{ items.status ? "抢购中" : "即将开始" }}</span>
                </li>
            </ul>
            <div>
                <swiper ref="mySwiper" :options="swiperOptions">
                    <swiper-slide
                        v-for="(items, index) in seckilllist"
                        :key="index"
                    >
                        <img :src="items.goods_thumb" alt="" />
                        <p>{{ items.goods_name }}</p>
                        <span>{{ items.sec_price_formated }}</span>
                        <del>{{ items.market_price_formated }}</del>
                    </swiper-slide>
                </swiper>
            </div>
            <p>更多秒杀商品<span class="iconfont icon-jiantou1"></span></p>
        </div>
    </div>
</template>

<script>
//这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
//例如：import 《组件名称》 from '《组件路径》';

export default {
    //import引入的组件需要注入到对象中才能使用
    components: {},
    data() {
        //这里存放数据
        return {
            hours: "00",
            minute: "00",
            second: "00",
            seckillflag: 0,
            swiperOptions: {
                slidesPerView: 3,
                // Some Swiper option/callback...
            },
        };
    },
    props: { timelist: Array, seckilllist: Array },
    //监听属性 类似于data概念
    computed: {
        swiper() {
            return this.$refs.mySwiper.$swiper;
        },
    },
    //监控data中的数据变化
    watch: {},
    //方法集合
    methods: {
        seckillactive(data) {
            this.seckillflag = data;
            // this.$emit("seckilltoparent",data);//为秒杀跳页做准备
        },
        seckilltime() {
            if (this.timelist) {
                let endtime = this.timelist[0];

                let thistime =
                    (+new Date(endtime.frist_end_time) - +new Date()) / 1000;
                this.hours = `${Math.floor(thistime / 60 / 60)}`.padStart(
                    2,
                    "0"
                );
                this.minute = `${Math.floor((thistime / 60) % 60)}`.padStart(
                    2,
                    "0"
                );
                this.second = `${Math.floor(thistime % 60)}`.padStart(2, "0");
            }
        },
    },
    beforeCreate() {}, //生命周期 - 创建之前
    //生命周期 - 创建完成（可以访问当前this实例）
    created() {},
    beforeMount() {}, //生命周期 - 挂载之前
    //生命周期 - 挂载完成（可以访问DOM元素）
    mounted() {
        // console.log("Current Swiper instance object", this.swiper);
        this.swiper.slideTo(3, 0, false);
        this.seckillinterval = setInterval(() => {
            this.seckilltime();
        }, 4);
    },
    beforeUpdate() {}, //生命周期 - 更新之前
    updated() {}, //生命周期 - 更新之后
    beforeDestroy() {}, //生命周期 - 销毁之前
    destroyed() {
        clearInterval(this.seckillinterval);
    }, //生命周期 - 销毁完成
    activated() {}, //如果页面有keep-alive缓存功能，这个函数会触发
};
</script>
<style lang="less">
.seckill {
    width: 100%;
    margin-top: 1rem;
    border-radius: 1.5rem;
    background: #fff;
    .seckilltitle {
        padding: 2.5rem 1.5rem 1rem;
        width: 100%;
        display: flex;
        align-items: center;
        justify-content: space-between;
        > img {
            width: 10rem;
        }
        .seckilltime {
            color: orangered;
            font-weight: bold;
            float: right;
            span {
                padding: 0.1rem 0.3rem;
                background: orangered;
                border-radius: 0.5rem;
                margin: 0 0.4rem;
                color: #fff;
            }
        }
    }
    .seckill-box {
        ul {
            height: 6rem;
            display: flex;
            justify-content: space-around;
            align-items: center;
            border-bottom: 1px solid #eee;
            li {
                transition: all 0.5 ease;
                text-align: center;
                font-weight: bold;
                color: #aaa;
                padding: 1.2rem 0;
            }
            > .seckillactive {
                font-size: 1.3rem;
                color: orangered;
                border-bottom: 2px solid orangered;
            }
        }
        > div {
            margin-top: 1rem;
            .swiper-wrapper {
                .swiper-slide {
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    padding: 0.5rem;
                    img {
                        width: 100%;
                    }
                    p {
                        width: 100%;
                        text-align: center;
                        overflow: hidden;
                        white-space: nowrap;
                        text-overflow: ellipsis;
                        color: #999;
                    }
                    span {
                        color: orangered;
                        font-size: 1.4rem;
                        font-weight: bold;
                    }
                    del {
                        color: #999;
                    }
                }
            }
        }
        > p {
            text-align: center;
            font-size: 1.3rem;
            line-height: 4rem;
            vertical-align: middle;
            > .icon-jiantou1 {
                vertical-align: middle;
            }
        }
    }
}
</style>
