<!-- 底部社区推荐 -->
<template>
    <div class="recommend-box" v-if="rdata">
        <ul
            v-infinite-scroll="loadMore"
            infinite-scroll-disabled="loading"
            infinite-scroll-distance="10"
        >
            <router-link tag="li" :to="'/goodsdetall/' + items.goods_id" v-for="(items, index) in rdata" :key="index">
                <img :src="items.goods_thumb" alt="" v-if="items.goods_thumb" />
                <img :src="items.img" alt="" v-else />
                <p>{{ items.title || items.goods_name }}</p>

                <span v-if="items.goods_thumb"
                    >{{ items.shop_price_formated }}
                </span>
                <span v-else>
                    <img :src="items.user_picture" alt="" />
                    <em>{{ items.user_name }}</em>
                    <s></s>
                    <i class="iconfont icon-xianshi">{{
                        items.dis_browse_num
                    }}</i>
                </span>
            </router-link>
        </ul>
        <div class="jz">
            <img src="@/assets/1-1Q020111TaH.gif" alt="" v-if="rundingstatus" />
            <div v-else><span>加载失败le</span></div>
        </div>
    </div>
    <div v-else></div>
</template>

<script>
//这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
//例如：import 《组件名称》 from '《组件路径》';

export default {
    //import引入的组件需要注入到对象中才能使用
    components: {},
    data() {
        //这里存放数据
        return {
            loading: false,
            rundingstatus: false,
        };
    },
    props: {
        rdata: Array,
    },
    //监听属性 类似于data概念
    computed: {},
    //监控data中的数据变化
    watch: {
        rdata: function(el) {
            if (!el.length) {
                this.rundingstatus = false;
            } else {
                this.rundingstatus = true;
            }
        },
    },
    //方法集合
    methods: {
        loadMore() {
            this.loading = true;
            this.rundingstatus = true;
            this.$emit("getrecommend", "加载中");
            setTimeout(() => {
                this.loading = false;
                this.rundingstatus = false;
            }, 2500);
        },
    },
    beforeCreate() {}, //生命周期 - 创建之前
    //生命周期 - 创建完成（可以访问当前this实例）
    created() {},
    beforeMount() {}, //生命周期 - 挂载之前
    //生命周期 - 挂载完成（可以访问DOM元素）
    mounted() {},
    beforeUpdate() {}, //生命周期 - 更新之前
    updated() {}, //生命周期 - 更新之后
    beforeDestroy() {}, //生命周期 - 销毁之前
    destroyed() {}, //生命周期 - 销毁完成
    activated() {}, //如果页面有keep-alive缓存功能，这个函数会触发
};
</script>
<style lang="less">
.recommend-box {
    ul {
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        li {
            width: 48%;
            height: 27rem;
            border-radius: 1.5rem;
            background: #fff;
            margin-top: 1rem;
            overflow: hidden;
            align-items: flex-start;
            position: relative;
            img {
                width: 100%;
            }
            p {
                padding: 0 1rem;
                font-size: 1.5rem;
                overflow: hidden; /* 溢出部分隐藏 */
                text-overflow: ellipsis; /* 文本最后显示省略号 */
                display: -webkit-box; /* 伸缩盒 */
                -webkit-line-clamp: 2; /* 文本显示行数 */
                -webkit-box-orient: vertical; /* 设置伸缩盒排列方式，从上到下排列 */
            }
            span {
                color: orangered;
                font-size: 1.5rem;
                line-height: 4rem;
                padding: 1rem;
                font-weight: bold;
                align-self: flex-end;
            }
            span {
                width: 100%;
                display: flex;
                align-items: center;
                position: absolute;
                bottom: 0;
                left: 0;
                img {
                    width: 2.5rem;
                    height: 2.5rem;
                    border-radius: 50%;
                }
                em {
                    font-style: normal;
                    font-size: 1rem;
                }
                s {
                    flex-grow: 1;
                }
                i {
                    font-size: 1rem;
                    color: #aaa;
                }
            }
        }
    }
}
.jz {
    width: 100%;
    height: 5rem;
    margin-top: 1rem;
    display: flex;
    justify-content: center;
    border-radius: 1.5rem;
    background: #fff;
    img {
        width: 5rem;
    }
    div {
        width: 100%;
        text-align: center;
        padding: 1rem 0;
        span {
            font-size: 2rem;
        }
    }
}
</style>
