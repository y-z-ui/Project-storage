<!--  -->
<template>
    <div class="Makeupagroup">
        <div class="title">
            <h3>拼团专区</h3>
            <p>拼着买更实惠<i class="iconfont icon-jiantou1"></i></p>
        </div>
        <div class="content">
            <swiper ref="mySwiper" :options="swiperOptions">
                <swiper-slide v-for="(items, index) in makeup" :key="index">
                    <img :src="items.goods_thumb" alt="" />
                    <p>{{ items.goods_name }}</p>
                    <span class="iconfont icon-pintuangou">{{
                        items.team_price_formated
                    }}</span>
                    <del>{{ items.shop_price_formated }}</del>
                </swiper-slide>
            </swiper>
        </div>
    </div>
</template>

<script>
//这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
//例如：import 《组件名称》 from '《组件路径》';

export default {
    //import引入的组件需要注入到对象中才能使用
    components: {},
    data() {
        //这里存放数据
        return {
            swiperOptions: {
                slidesPerView: 3,
                // Some Swiper option/callback...
            },
        };
    },
    props: { makeup: Array },
    //监听属性 类似于data概念
    computed: {
        swiper() {
            return this.$refs.mySwiper.$swiper;
        },
    },
    //监控data中的数据变化
    watch: {},
    //方法集合
    methods: {},
    beforeCreate() {}, //生命周期 - 创建之前
    //生命周期 - 创建完成（可以访问当前this实例）
    created() {},
    beforeMount() {}, //生命周期 - 挂载之前
    //生命周期 - 挂载完成（可以访问DOM元素）
    mounted() {
        this.swiper.slideTo(3, 1000, false);
    },
    beforeUpdate() {}, //生命周期 - 更新之前
    updated() {}, //生命周期 - 更新之后
    beforeDestroy() {}, //生命周期 - 销毁之前
    destroyed() {}, //生命周期 - 销毁完成
    activated() {}, //如果页面有keep-alive缓存功能，这个函数会触发
};
</script>
<style lang="less">
.Makeupagroup {
    border-radius: 1.5rem;
    background: #fff;
    padding: 1rem 1.2rem;
    margin-top: 1rem;
    > .title {
        display: flex;
        align-items: flex-start;
        padding: 1.2rem 0rem;
        border-bottom: 1px solid #ccc;
        > h3 {
            font-size: 2rem;
            font-weight: bold;
        }
        > p {
            margin-left: 1rem;
            font-size: 1.3rem;
            align-self: flex-end;
            color: #ccc;
            > i {
                margin-left: 0.4rem;
                border-radius: 50%;
                border: 1px solid orangered;
                font-size: 1rem;
            }
            > i::before {
                color: orangered;
                text-align: center;
            }
        }
    }
    > .content {
        padding: 1.2rem 0rem;
        .swiper-wrapper {
            .swiper-slide {
                display: flex;
                flex-direction: column;
                align-items: center;
                padding: 0.1rem;
                img {
                    width: 100%;
                    height: 10.9rem;
                }
                p {
                    width: 100%;
                    text-align: center;
                    overflow: hidden;
                    white-space: nowrap;
                    text-overflow: ellipsis;
                    color: #999;
                }
                span {
                    color: orangered;
                    font-size: 1.4rem;
                    font-weight: bold;
                }
                > span::before {
                    margin-right: 0.4rem;
                }
                del {
                    color: #999;
                }
            }
        }
    }
}
</style>
