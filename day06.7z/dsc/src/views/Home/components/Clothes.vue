<!-- 品质服饰 -->
<template>
    <div class="clothes-box">
        <div>
            <div
                class="swiperslide"
                v-for="(items, index) in maxdata"
                :key="index"
            >
                <img :src="items.goods_img" alt="" />
                <p>{{ items.title }}</p>
                <span>{{ "￥" + items.shop_price }}</span>
            </div>
        </div>
    </div>
</template>

<script>
//这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
//例如：import 《组件名称》 from '《组件路径》';

export default {
    //import引入的组件需要注入到对象中才能使用
    components: {},
    data() {
        //这里存放数据
        return {};
    },
    props: { maxdata: Array },
    //监听属性 类似于data概念
    computed: {},
    //监控data中的数据变化
    watch: {},
    //方法集合
    methods: {},
    beforeCreate() {}, //生命周期 - 创建之前
    //生命周期 - 创建完成（可以访问当前this实例）
    created() {},
    beforeMount() {}, //生命周期 - 挂载之前
    //生命周期 - 挂载完成（可以访问DOM元素）
    mounted() {},
    beforeUpdate() {}, //生命周期 - 更新之前
    updated() {}, //生命周期 - 更新之后
    beforeDestroy() {}, //生命周期 - 销毁之前
    destroyed() {}, //生命周期 - 销毁完成
    activated() {}, //如果页面有keep-alive缓存功能，这个函数会触发
};
</script>
<style lang="less">
.clothes-box {
    width: 100%;
    padding-left: 1.2rem;
    padding-right: 1.2rem;
    margin-top: 1rem;
    

    
    padding-top: 12rem;
    padding-bottom: 2rem;

    > div {
        width: 100%;
        display: flex;
        justify-content: space-between;
        flex-wrap: wrap;
        .swiperslide {
            width: 32%;
            height: 17.9rem;
            border-radius: 1.5rem;
            overflow: hidden;
            background-color: #fff;
            margin-top: 1rem;
            img {
                width: 100%;
            }
            p {
                height: 4rem;
                overflow: hidden;
                text-overflow: ellipsis;
                display: -webkit-box;
                -webkit-line-clamp: 2;
                -webkit-box-orient: vertical;
                padding: 1rem 0.5rem;
                line-height: 1.5rem;
            }
            span {
                padding: 1.5rem 0.5rem;
                line-height: 3rem;
                color: orangered;
            }
        }
    }
}
</style>
