<!-- 头部导航 -->
<template>
    <div class="home-header">
        <form action="" class="head-search">
            <router-link to="/seach" tag="div">
                <input type="text" placeholder="搜索商品名称" />
                <i class="iconfont icon-sousuo"></i>
            </router-link>
            <span class="iconfont icon-xiaoxi"></span>
        </form>
        <div class="head-nav">
            <ly-tab
                v-model="selectedId"
                :items="items"
                :options="options"
                @change="headnav"
            >
            </ly-tab>
            <span class="iconfont icon-fenlei">分类</span>
        </div>
    </div>
</template>

<script>
//这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
//例如：import 《组件名称》 from '《组件路径》';

export default {
    //import引入的组件需要注入到对象中才能使用
    components: {},
    data() {
        //这里存放数据
        return {
            selectedId: 0,
            items: [
                { label: "首页" },
                { label: "家用电器" },
                { label: "男装女装" },
                { label: "鞋靴箱包" },
                { label: "手机数码" },
                { label: "电脑办公" },
                { label: "家居家纺" },
                { label: "个人化妆" },
            ],
            options: {
                activeColor: "#fff",
            },
            linkdata: [
                "/home/index",
                "/home/appliances",
                "/home/clothing",
                "/home/shoebags",
                "/home/figurt",
                "/home/computer",
                "/home/hometextiles",
                "/home/makeup",
            ],
        };
    },
    //监听属性 类似于data概念
    computed: {},
    //监控data中的数据变化
    watch: {},
    //方法集合
    methods: {
        headnav(item, index) {
            this.$router.push(this.linkdata[index]);
        },
    },
    beforeCreate() {}, //生命周期 - 创建之前
    //生命周期 - 创建完成（可以访问当前this实例）
    created() {},
    beforeMount() {}, //生命周期 - 挂载之前
    //生命周期 - 挂载完成（可以访问DOM元素）
    mounted() {
        this.linkdata.forEach((value, index) => {
            if (this.$route.path == value) {
                this.selectedId = index;
            }
        });
    },
    beforeUpdate() {}, //生命周期 - 更新之前
    updated() {}, //生命周期 - 更新之后
    beforeDestroy() {}, //生命周期 - 销毁之前
    destroyed() {}, //生命周期 - 销毁完成
    activated() {}, //如果页面有keep-alive缓存功能，这个函数会触发
};
</script>
<style lang="less">
.home-header {
    width: 100%;
    background: transparent;
    padding: 1rem 0;
    > .head-search {
        width: 100%;
        display: flex;
        justify-content: space-between;
        > div {
            width: 90%;
            position: relative;
            padding-left: 1rem;
            > input {
                width: 100%;
                height: 2.6rem;
                text-indent: 2rem;
                border-radius: 1.4rem;
            }
            > i {
                position: absolute;
                top: 0;
                right: 1rem;
                line-height: 2.6rem;
                color: #ccc;
                font-weight: 100;
            }
        }
        > span {
            width: 10%;
            height: 2.6rem;
            text-align: center;
            font-size: 2rem;
            color: #fff;
        }
    }
    .head-nav {
        width: 100%;
        display: flex;

        > .ly-tab {
            width: 85%;
            > .ly-tabbar {
                width: 100%;
                background: transparent;
                border-bottom: 0;
                box-shadow: none;
                .ly-tab-list {
                    color: #fff;
                }
            }
        }
        > span {
            width: 15%;
            color: #fff;
            font-size: 1.4rem;
            line-height: 4.6rem;
        }
        > span::before {
            font-size: 2.2rem;
            vertical-align: middle;
            box-shadow: -6px 0 4px -4px rgba(0, 0, 0, 0.4);
        }
    }
}
</style>
