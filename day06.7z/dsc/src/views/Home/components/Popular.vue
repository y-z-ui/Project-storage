<!-- 潮流科技 -->
<template>
    <div class="Popular-box">
        <Swiper :maxdata="maxdata" />
    </div>
</template>

<script>
//这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
//例如：import 《组件名称》 from '《组件路径》';
import Swiper from "@/components/swiper";
export default {
    //import引入的组件需要注入到对象中才能使用
    components: {
        Swiper,
    },
    data() {
        //这里存放数据
        return {};
    },
    props: { maxdata: Array },
    //监听属性 类似于data概念
    computed: {},
    //监控data中的数据变化
    watch: {},
    //方法集合
    methods: {},
    beforeCreate() {}, //生命周期 - 创建之前
    //生命周期 - 创建完成（可以访问当前this实例）
    created() {},
    beforeMount() {}, //生命周期 - 挂载之前
    //生命周期 - 挂载完成（可以访问DOM元素）
    mounted() {},
    beforeUpdate() {}, //生命周期 - 更新之前
    updated() {}, //生命周期 - 更新之后
    beforeDestroy() {}, //生命周期 - 销毁之前
    destroyed() {}, //生命周期 - 销毁完成
    activated() {}, //如果页面有keep-alive缓存功能，这个函数会触发
};
</script>
<style lang="less">
.Popular-box {
    width: 100%;

    margin-top: 1rem;
    border-radius: 1.5rem;
    background: url(https://demo.dscmall.cn/storage/data/gallery_album/original_img/2xrOpGBonnFxQRzbgIEDM55NFSh0YHuTlQtap6Df.jpeg?imageView2/2/format/webp)
        no-repeat 0px 0px;
    background-size: 100%;
    padding-left: 1.2rem;
    padding-right: 1.2rem;
    padding-top: 12rem;
}
</style>
