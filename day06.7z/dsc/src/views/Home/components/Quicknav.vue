<!--  -->
<template>
    <div class="quicknav">
        <div class="quicknav-up">
            <mt-swipe :auto="0" :continuous="false">
                <mt-swipe-item
                    v-for="(items, index) in quicknavdata"
                    :key="index"
                >
                    <ul>
                        <li v-for="(value, index) in items" :key="index">
                            <img :src="value.imgsrc" alt="" /><span>{{
                                value.title
                            }}</span>
                        </li>
                    </ul>
                </mt-swipe-item>
            </mt-swipe>
        </div>
        <div class="quicknav-down">
            <img
                src="https://x.dscmall.cn/storage/data/gallery_album/177/original_img/177_P_1597978466633.png"
                alt=""
            />
            <div>
                <ul :class="[{ newsplay: true }, { trans: flag }]">
                    <li v-for="(value, index) in navnews" :key="index">
                        {{ value }}
                    </li>
                </ul>
            </div>
            <i class="iconfont icon-jiantou1"></i>
        </div>
    </div>
</template>

<script>
//这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
//例如：import 《组件名称》 from '《组件路径》';

export default {
    //import引入的组件需要注入到对象中才能使用
    components: {},
    data() {
        //这里存放数据
        return {
            quicknavdata: [
                [
                    {
                        title: "潮流服饰",
                        imgsrc:
                            "https://x.dscmall.cn/storage/data/gallery_album/original_img/9JVcPMp5TemauXCVQxnIY50u80vcxnFGfnn33CKh.png?imageView2/2/format/webp",
                    },
                    {
                        title: "潮流服饰",
                        imgsrc:
                            "https://x.dscmall.cn/storage/data/gallery_album/original_img/9JVcPMp5TemauXCVQxnIY50u80vcxnFGfnn33CKh.png?imageView2/2/format/webp",
                    },
                    {
                        title: "潮流服饰",
                        imgsrc:
                            "https://x.dscmall.cn/storage/data/gallery_album/original_img/9JVcPMp5TemauXCVQxnIY50u80vcxnFGfnn33CKh.png?imageView2/2/format/webp",
                    },
                    {
                        title: "潮流服饰",
                        imgsrc:
                            "https://x.dscmall.cn/storage/data/gallery_album/original_img/9JVcPMp5TemauXCVQxnIY50u80vcxnFGfnn33CKh.png?imageView2/2/format/webp",
                    },
                    {
                        title: "潮流服饰",
                        imgsrc:
                            "https://x.dscmall.cn/storage/data/gallery_album/original_img/9JVcPMp5TemauXCVQxnIY50u80vcxnFGfnn33CKh.png?imageView2/2/format/webp",
                    },
                    {
                        title: "潮流服饰",
                        imgsrc:
                            "https://x.dscmall.cn/storage/data/gallery_album/original_img/9JVcPMp5TemauXCVQxnIY50u80vcxnFGfnn33CKh.png?imageView2/2/format/webp",
                    },
                    {
                        title: "潮流服饰",
                        imgsrc:
                            "https://x.dscmall.cn/storage/data/gallery_album/original_img/9JVcPMp5TemauXCVQxnIY50u80vcxnFGfnn33CKh.png?imageView2/2/format/webp",
                    },
                    {
                        title: "潮流服饰",
                        imgsrc:
                            "https://x.dscmall.cn/storage/data/gallery_album/original_img/9JVcPMp5TemauXCVQxnIY50u80vcxnFGfnn33CKh.png?imageView2/2/format/webp",
                    },
                    {
                        title: "潮流服饰",
                        imgsrc:
                            "https://x.dscmall.cn/storage/data/gallery_album/original_img/9JVcPMp5TemauXCVQxnIY50u80vcxnFGfnn33CKh.png?imageView2/2/format/webp",
                    },
                    {
                        title: "潮流服饰",
                        imgsrc:
                            "https://x.dscmall.cn/storage/data/gallery_album/original_img/9JVcPMp5TemauXCVQxnIY50u80vcxnFGfnn33CKh.png?imageView2/2/format/webp",
                    },
                ],
                [
                    {
                        title: "潮流服饰",
                        imgsrc:
                            "https://x.dscmall.cn/storage/data/gallery_album/original_img/9JVcPMp5TemauXCVQxnIY50u80vcxnFGfnn33CKh.png?imageView2/2/format/webp",
                    },
                    {
                        title: "潮流服饰",
                        imgsrc:
                            "https://x.dscmall.cn/storage/data/gallery_album/original_img/9JVcPMp5TemauXCVQxnIY50u80vcxnFGfnn33CKh.png?imageView2/2/format/webp",
                    },
                    {
                        title: "潮流服饰",
                        imgsrc:
                            "https://x.dscmall.cn/storage/data/gallery_album/original_img/9JVcPMp5TemauXCVQxnIY50u80vcxnFGfnn33CKh.png?imageView2/2/format/webp",
                    },
                    {
                        title: "潮流服饰",
                        imgsrc:
                            "https://x.dscmall.cn/storage/data/gallery_album/original_img/9JVcPMp5TemauXCVQxnIY50u80vcxnFGfnn33CKh.png?imageView2/2/format/webp",
                    },
                    {
                        title: "潮流服饰",
                        imgsrc:
                            "https://x.dscmall.cn/storage/data/gallery_album/original_img/9JVcPMp5TemauXCVQxnIY50u80vcxnFGfnn33CKh.png?imageView2/2/format/webp",
                    },
                    {
                        title: "潮流服饰",
                        imgsrc:
                            "https://x.dscmall.cn/storage/data/gallery_album/original_img/9JVcPMp5TemauXCVQxnIY50u80vcxnFGfnn33CKh.png?imageView2/2/format/webp",
                    },
                    {
                        title: "潮流服饰",
                        imgsrc:
                            "https://x.dscmall.cn/storage/data/gallery_album/original_img/9JVcPMp5TemauXCVQxnIY50u80vcxnFGfnn33CKh.png?imageView2/2/format/webp",
                    },
                    {
                        title: "潮流服饰",
                        imgsrc:
                            "https://x.dscmall.cn/storage/data/gallery_album/original_img/9JVcPMp5TemauXCVQxnIY50u80vcxnFGfnn33CKh.png?imageView2/2/format/webp",
                    },
                    {
                        title: "潮流服饰",
                        imgsrc:
                            "https://x.dscmall.cn/storage/data/gallery_album/original_img/9JVcPMp5TemauXCVQxnIY50u80vcxnFGfnn33CKh.png?imageView2/2/format/webp",
                    },
                    {
                        title: "潮流服饰",
                        imgsrc:
                            "https://x.dscmall.cn/storage/data/gallery_album/original_img/9JVcPMp5TemauXCVQxnIY50u80vcxnFGfnn33CKh.png?imageView2/2/format/webp",
                    },
                ],
            ],
            navnews: [
                "服务店突破2000多家",
                "三大国际腕表品牌签约",
                "发售广告位，先到先得",
            ],
            flag: false,
        };
    },
    //监听属性 类似于data概念
    computed: {},
    //监控data中的数据变化
    watch: {},
    //方法集合
    methods: {
        scrollNewsFn() {
            let oUl = document.querySelector(".newsplay"); //获取ul  dom元素
            oUl.style.top = "-3rem";
            this.flag = !this.flag;
            setTimeout(() => {
                this.navnews.push(this.navnews[0]);
                this.navnews.shift();
                oUl.style.top = "0rem";
                this.flag = !this.flag;
            }, 500);
        },
    },
    beforeCreate() {}, //生命周期 - 创建之前
    //生命周期 - 创建完成（可以访问当前this实例）
    created() {},
    beforeMount() {}, //生命周期 - 挂载之前
    //生命周期 - 挂载完成（可以访问DOM元素）
    mounted() {
        this.timer = setInterval(this.scrollNewsFn, 2000);
    },
    beforeUpdate() {}, //生命周期 - 更新之前
    updated() {}, //生命周期 - 更新之后
    beforeDestroy() {}, //生命周期 - 销毁之前
    destroyed() {
        clearInterval(this.timer);
    }, //生命周期 - 销毁完成
    activated() {}, //如果页面有keep-alive缓存功能，这个函数会触发
};
</script>
<style lang="less">
.quicknav {
    width: 100%;
    margin-top: 1rem;
    box-shadow: 0px 0px 0px 1px #eee;
    border-radius: 1.2rem;
    overflow: hidden;
    background: #fff;
    .quicknav-up {
        height: 20rem;
        .mint-swipe {
            .mint-swipe-item {
                ul {
                    display: flex;
                    flex-wrap: wrap;
                    li {
                        display: flex;
                        flex-direction: column;
                        align-items: center;
                        img {
                            width: 7rem;
                        }
                    }
                }
            }
            .mint-swipe-indicator {
                width: 2rem;
                height: 0.4rem;
                border-radius: 0;
                background: orangered;
                margin: 0;
                border-radius: 1rem;
            }
            .mint-swipe-indicator.is-active {
                background: orangered;
                opacity: 1;
            }
        }
    }
    .quicknav-down {
        width: 100%;
        margin: 0 1.2rem;
        border-top: 1px solid #0000000f;
        display: flex;
        align-items: center;
        padding: 0.8rem 0;
        img {
            width: 20%;
        }
        > div {
            width: 70%;
            height: 3rem;
            overflow: hidden;
            position: relative;
            ul {
                position: absolute;
                top: 0;
                left: 0;
                li {
                    padding-left: 1rem;
                    line-height: 3rem;
                }
            }
        }
        i {
            width: 1.6rem;
            height: 1.5rem;
            line-height: 1.2rem;
            text-align: center;
            color: orangered;
            border: 1px solid orangered;
            border-radius: 50%;
        }
    }
}
.trans {
    transition: all 1s ease;
}
</style>
