<!-- 首页轮播图 -->
<template>
    <div class="rotation">
        <mt-swipe :auto="3000" @change="handleChange">
            <mt-swipe-item
                ><img
                    src="https://x.dscmall.cn/storage/data/gallery_album/177/original_img/177_P_1597978394783.jpg"
                    alt=""
            /></mt-swipe-item>
            <mt-swipe-item
                ><img
                    src="https://x.dscmall.cn/storage/data/gallery_album/177/original_img/177_P_1597978396430.jpg"
                    alt=""
            /></mt-swipe-item>
            <mt-swipe-item
                ><img
                    src="https://x.dscmall.cn/storage/data/gallery_album/177/original_img/177_P_1597978395241.jpg"
                    alt=""
            /></mt-swipe-item>
            <mt-swipe-item
                ><img
                    src="https://x.dscmall.cn/storage/data/gallery_album/177/original_img/177_P_1597978395260.jpg"
                    alt=""
            /></mt-swipe-item>
            <mt-swipe-item
                ><img
                    src="https://x.dscmall.cn/storage/data/gallery_album/177/original_img/177_P_1597978397105.jpg"
                    alt=""
            /></mt-swipe-item>
        </mt-swipe>
    </div>
</template>

<script>
//这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
//例如：import 《组件名称》 from '《组件路径》';

export default {
    //import引入的组件需要注入到对象中才能使用
    components: {},
    data() {
        //这里存放数据
        return {
            colorArray: ["#E43124", "#E33124", "#3C81FF", "#028379", "#3C81FF"],
        };
    },
    //监听属性 类似于data概念
    computed: {},
    //监控data中的数据变化
    watch: {},
    //方法集合
    methods: {
        handleChange(index) {
            document.querySelectorAll(
                ".rotation-bgc"
            )[0].style.background = document.querySelectorAll(
                ".rotation-bgc"
            )[1].style.background = this.colorArray[index];
        },
    },
    beforeCreate() {}, //生命周期 - 创建之前
    //生命周期 - 创建完成（可以访问当前this实例）
    created() {},
    beforeMount() {}, //生命周期 - 挂载之前
    //生命周期 - 挂载完成（可以访问DOM元素）
    mounted() {},
    beforeUpdate() {}, //生命周期 - 更新之前
    updated() {}, //生命周期 - 更新之后
    beforeDestroy() {}, //生命周期 - 销毁之前
    destroyed() {}, //生命周期 - 销毁完成
    activated() {}, //如果页面有keep-alive缓存功能，这个函数会触发
};
</script>
<style lang="less">
.rotation {
    width: 100%;
    height: 12rem;
    padding: 0 1.2rem;
    position: relative;
    z-index: 1000;
    .mint-swipe {
        overflow: hidden;
        border-radius: 1.5rem;
        .mint-swipe-items-wrap {
            .mint-swipe-item {
                img {
                    width: 100%;
                }
            }
        }
        .mint-swipe-indicators {
            position: absolute;
            bottom: 1rem;
            left: 4rem;
        }
    }
}
</style>
