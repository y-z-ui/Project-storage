<!--  -->
<template>
    <div class="home-index">
        <div class="home-rotation">
            <div class="rotation-bgc"></div>
            <Rotation />
        </div>
        <div class="quick-nav">
            <Quicknav />
        </div>
        <div class="school-time">
            <img
                src="https://x.dscmall.cn/storage/data/gallery_album/original_img/CPvH5WHHbF0EoG9XjRQbbT3knMVCeEt9DlYGQhJM.png?imageView2/2/format/webp"
                alt=""
            />
        </div>
        <div class="seckill-time">
            <Seckill :timelist="timelist" :seckilllist="seckilllist" />
        </div>
        <div class="Makeup">
            <Makeupagroup :makeup="makeup" />
        </div>
        <div class="beautycare">
            <Beautycare :maxdata="checked1data" />
        </div>
        <div class="beautycare">
            <Popular :maxdata="checked2data" />
        </div>
        <div class="beautycare3">
            <Clothes :maxdata="checked3data" />
        </div>
        <div class="beautycare4">
            <Clothes :maxdata="checked4data" />
        </div>
        <div class="recommend">
            <ul>
                <li
                    v-for="(value, index) in r_data"
                    :key="index"
                    :class="{ r_active: rflagindex == value.id }"
                    @click="r_recommend(value.id, value.URL, value.type)"
                >
                    <p>{{ value.title }}</p>
                    <span>{{ value.describe }}</span>
                </li>
            </ul>
            <Recommend :rdata="rdata" @getrecommend="getrecommend" />
        </div>
    </div>
</template>

<script>
//这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
//例如：import 《组件名称》 from '《组件路径》';
import Rotation from "../components/Rotation";
import Quicknav from "../components/Quicknav";
import Seckill from "../components/Seckill";
import Recommend from "../components/Recommend";
import Makeupagroup from "../components/Makeupagroup";
import Beautycare from "../components/Beautycare";
import Popular from "../components/Popular";
import Clothes from "../components/Clothes";
import { getHomeList } from "@/api/api";

// import Axios from "axios";

export default {
    //import引入的组件需要注入到对象中才能使用
    components: {
        Rotation,
        Quicknav,
        Seckill,
        Recommend,
        Makeupagroup,
        Beautycare,
        Popular,
        Clothes,
    },
    data() {
        //这里存放数据
        return {
            timelist: null,
            seckilllist: null,
            r_data: [
                {
                    id: 0,
                    title: "精选",
                    describe: "为你推荐",
                    URL: "/goods/type_list",
                    type: "is_best",
                },
                {
                    id: 1,
                    title: "社区",
                    describe: "新奇好物",
                    URL: "/discover/find_list",
                    type: "",
                },
                {
                    id: 2,
                    title: "新品",
                    describe: "潮流上新",
                    URL: "/goods/type_list",
                    type: "is_new",
                },
                {
                    id: 3,
                    title: "热卖",
                    describe: "火热爆款",
                    URL: "/goods/type_list",
                    type: "is_hot",
                },
            ],
            rflagindex: 0,
            rdata: [],
            url: "/goods/type_list",
            page: 1,
            size: 10,
            type: "is_best",
            makeup: [],
            checked1data: [],
            checked2data: [],
            checked3data: [],
            checked4data: [],
        };
    },
    //监听属性 类似于data概念
    computed: {},
    //监控data中的数据变化
    watch: {},
    //方法集合
    methods: {
        async getdatas() {
            let result = await getHomeList("/visual/visual_seckill", {
                page: "",
                size: "",
                type: "",
            });
            this.seckilllist = result.data.seckill_list;
            this.timelist = result.data.time_list;
        },
        r_recommend(datas, url, type) {
            this.rdata = [];
            this.page = 1;
            this.rflagindex = datas;
            this.type = type;
            this.url = url;
            this.getrdata();
        },
        getrecommend(data) {
            data;
            this.page += 1;
            this.getrdata();
        },
        async getrdata() {
            let result = await getHomeList(this.url, {
                page: this.page,
                size: this.size,
                type: this.type,
            });
            this.rdata = this.rdata.concat(result.data);
        },
        async makeupagroup() {
            let result = await getHomeList("/visual/visual_team_goods", {
                page: "",
                size: "",
                type: "",
            });
            this.makeup = result.data;
        },
        async getchecked1data() {
            let result = await getHomeList(
                "/visual/checked",
                {
                    number: 6,
                    goods_id: "888,890,892,887,886,644",
                },
                "post"
            );
            this.checked1data = result.data;
        },
        async getchecked2data() {
            let result = await getHomeList(
                "/visual/checked",
                {
                    number: 6,
                    goods_id: "985,984,851,818,849,1020",
                },
                "post"
            );
            this.checked2data = result.data;
        },
        async getchecked3data() {
            let result = await getHomeList(
                "/visual/checked",
                {
                    number: 6,
                    goods_id: "874,993,635,792,625,788",
                },
                "post"
            );
            this.checked3data = result.data;
        },
        async getchecked4data() {
            let result = await getHomeList(
                "/visual/checked",
                {
                    number: 6,
                    goods_id: "989,990,838,837,677,678",
                },
                "post"
            );
            this.checked4data = result.data;
        },
    },
    beforeCreate() {}, //生命周期 - 创建之前
    //生命周期 - 创建完成（可以访问当前this实例）
    created() {},
    beforeMount() {}, //生命周期 - 挂载之前
    //生命周期 - 挂载完成（可以访问DOM元素）
    mounted() {
        if (this.$route.path == "/home/index") {
            document.querySelectorAll(
                ".rotation-bgc"
            )[0].style.background = document.querySelectorAll(
                ".rotation-bgc"
            )[1].style.background = "#E43124";
        }
        this.getdatas();
        this.getrdata();
        this.makeupagroup();
        this.getchecked1data();
        this.getchecked2data();
        this.getchecked3data();
        this.getchecked4data();
        
    },
    beforeUpdate() {}, //生命周期 - 更新之前
    updated() {}, //生命周期 - 更新之后
    beforeDestroy() {}, //生命周期 - 销毁之前
    destroyed() {}, //生命周期 - 销毁完成
    activated() {}, //如果页面有keep-alive缓存功能，这个函数会触发
};
</script>
<style lang="less">
.home-index {
    background: #eee;
    width: 100%;
    .home-rotation {
        width: 100%;
        position: relative;
        .rotation-bgc {
            transition: all 0.5s ease;
            position: absolute;
            top: 0;
            left: 0;
            background: red;
            width: 100%;
            height: 8rem;
            border-bottom-right-radius: 50%;
            border-bottom-left-radius: 50%;
        }
    }
    .quick-nav,
    .seckill-time,
    .school-time,
    .Makeup,
    .beautycare {
        width: 100%;
        padding: 0 1.2rem;
    }
    .school-time {
        img {
            margin-top: 1rem;
            width: 100%;
        }
    }
    .recommend {
        width: 100%;
        padding: 0 1.2rem;
        > ul {
            width: 100%;
            display: flex;
            padding: 1rem 0;
            > li {
                text-align: center;
                width: 25%;
                line-height: 2.2rem;
                border-left: 1px solid #ccc;
                border-right: 1px solid #ccc;
                > p {
                    font-size: 1.5rem;
                    font-weight: bold;
                }
            }
            > .r_active {
                span {
                    color: #fff;
                    background: orangered;
                    border-radius: 2rem;
                    padding: 0 1rem;
                }
            }
            > li:first-of-type {
                border-left: none;
            }
            > li:last-of-type {
                border-right: none;
            }
        }
    }
    .beautycare3 {
        width: 93%;
        border-radius: 1.5rem;
        margin: 0 auto;
        background: url(https://demo.dscmall.cn/storage/data/gallery_album/original_img/mq7rYptqRIC6iWYkBUfWzdHGrusH4W1sCAQbHLHj.jpeg?imageView2/2/format/webp)
                no-repeat 0px 0px,
            #cdb7a0;
        background-size: 100%;
    }
    .beautycare4 {
        width: 93%;
        border-radius: 1.5rem;
        margin: 0 auto;
        background: url(https://demo.dscmall.cn/storage/data/gallery_album/original_img/CzzkibenhBz3Jcc8clYHc9imT29vc6InLFdKuN0U.jpeg?imageView2/2/format/webp)
                no-repeat 0px 0px,
            #2b4d69;
        background-size: 100%;
    }
}
</style>
