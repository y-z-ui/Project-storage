<!-- 搜索界面 -->
<template>
    <div class="seach">
        <div class="seach-box">
            <div class="toback">
                <span class="iconfont icon-jiantou3"></span>
            </div>
            <form action="javaScript:;">
                <label for="" class="inputbox">
                    <input
                        ref="searchbox"
                        type="text"
                        :placeholder="tishi ? tishi[0] : '请输入关键字'"
                        v-model="seachdata"
                        name="keywords"
                    />
                    <span
                        class="iconfont icon-chahao"
                        v-show="seachdata"
                        @click="removedata"
                    ></span>
                    <span class="iconfont icon-sousuo2"></span>
                </label>
                <button @click="searchmsg" type="button" class="seachchar">
                    搜索
                </button>
            </form>
        </div>
        <div class="latelyseach">
            <h3>最近搜索</h3>
            <ul class="late">
                <li
                    @click="toseach"
                    v-show="tishi"
                    v-for="(value, index) in tishi"
                    :key="index"
                >
                    {{ value }}
                </li>
                <li v-show="!tishi">暂无</li>
            </ul>
        </div>
        <div class="hotseach">
            <h3>热门搜索</h3>
            <ul class="hot">
                <li @click="toseach" v-for="(value, index) in hot" :key="index">
                    {{ value }}
                </li>
            </ul>
        </div>
    </div>
</template>

<script>
//这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
//例如：import 《组件名称》 from '《组件路径》';

export default {
    //import引入的组件需要注入到对象中才能使用
    components: {},
    data() {
        //这里存放数据
        return {
            seachdata: "",
            hot: ["周大福", "手机", "电脑", "数码"],
        };
    },
    //监听属性 类似于data概念
    computed: {
        tishi() {
            return JSON.parse(localStorage.getItem("latelyseach"));
        },
    },
    //监控data中的数据变化
    watch: {},
    //方法集合
    methods: {
        searchmsg() {
            if (!this.seachdata) {
                if (this.$refs.searchbox.placeholder == "请输入关键字") return;
                this.$router.push(
                    "/seachlist?keywords=" + this.$refs.searchbox.placeholder
                );
            } else {
                this.$router.push("/seachlist?keywords=" + this.seachdata);
                this.readlocal();
            }
        },
        readlocal() {
            if (!localStorage.getItem("latelyseach")) {
                localStorage.setItem(
                    "latelyseach",
                    JSON.stringify([this.seachdata])
                );
            } else {
                let data = JSON.parse(localStorage.getItem("latelyseach"));
                let index = data.indexOf(this.seachdata);

                if (index !== -1) {
                    data.splice(index, 1);
                }
                data.unshift(this.seachdata);
                localStorage.setItem("latelyseach", JSON.stringify(data));
            }
        },
        removedata() {
            console.log(1);
            this.seachdata = "";
        },
        toseach() {
            this.seachdata = event.target.innerText;
            this.searchmsg();
        },
    },
    beforeCreate() {}, //生命周期 - 创建之前
    //生命周期 - 创建完成（可以访问当前this实例）
    created() {},
    beforeMount() {}, //生命周期 - 挂载之前
    //生命周期 - 挂载完成（可以访问DOM元素）
    mounted() {},
    beforeUpdate() {}, //生命周期 - 更新之前
    updated() {}, //生命周期 - 更新之后
    beforeDestroy() {}, //生命周期 - 销毁之前
    destroyed() {}, //生命周期 - 销毁完成
    activated() {}, //如果页面有keep-alive缓存功能，这个函数会触发
};
</script>
<style lang="less" copay>
html,
body {
    width: 100%;
    background: #cccccc50;
}
.seach {
    background: #fff;
}
.seach-box {
    width: 100%;
    height: 4.4rem;
    border-bottom: 1px solid #cccccc50;
    display: flex;
    align-items: center;
    text-align: center;
    .toback {
        width: 10%;
        height: 4rem;
        span {
            font-size: 2rem;
            line-height: 4rem;
        }
    }
    form {
        width: 90%;
    }
    .inputbox {
        width: 85%;
        position: relative;
        input {
            width: 85%;
            height: 3rem;
            padding-left: 1.2rem;
            border: 1px solid #cccccc;
            border-radius: 1.5rem;
        }
        span {
            font-size: 1.6rem;
            position: absolute;
            top: 0;
        }
        span:first-of-type {
            right: 4rem;
            font-weight: bold;
            color: orangered;
        }
        span:last-of-type {
            right: 1.2rem;
        }
    }
    .seachchar {
        width: 15%;
        height: 4rem;
        font-size: 1.6rem;
        line-height: 4rem;
        background: #fff;
    }
}
.latelyseach,
.hotseach {
    width: 100%;
    padding: 1.2rem;
    h3 {
        font-size: 1.5rem;
        font-weight: 450;
        color: #333;
    }
    ul {
        margin: 1rem;
        display: flex;
        li {
            padding: 0.4rem 0.8rem;
            background: #cccccc70;
            border-radius: 0.6rem;
            margin-right: 0.4rem;
            margin-top: 0.8rem;
            color: #333;
        }
    }
}
</style>
