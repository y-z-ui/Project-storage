<!-- 登陆注册 -->
<template>
    <div class="administrator">
        <header class="a_header">
            <span class="iconfont icon-jiantou3"></span>
        </header>
        <div class="a_content">
            <h2>用户登录</h2>
            <ul class="landingmode">
                <router-link
                    to="/administrator/1"
                    tag="li"
                    :class="{ 'li-active': lang }"
                    >账号密码登陆</router-link
                >
                <router-link
                    to="/administrator/0"
                    tag="li"
                    :class="{ 'li-active': !lang }"
                    >短信验证码登陆</router-link
                >
            </ul>
            <!-- 账号密码登录 -->
            <form action="" method="POST" v-if="lang">
                <label class="captcha">
                    <span class="iconfont icon-pic"></span>
                    <input
                        type="text"
                        placeholder="请输入验证码"
                        name="captcha"
                        v-model="captcha"
                    />
                    <img
                        src="http://192.168.1.7:3000/admin/randomcaptcha"
                        alt=""
                        @click="obtainrandom"
                        ref="svgycm"
                    />
                </label>
                <label class="username">
                    <span class="iconfont icon-wode"></span>
                    <input
                        type="text"
                        @change="userlength"
                        placeholder="请输入你的用户名/手机号"
                        name="username"
                        v-model="username"
                    />
                </label>
                <label class="password">
                    <span class="iconfont icon-icon-pwd"></span>
                    <input
                        type="password"
                        placeholder="请输入登录密码"
                        v-if="!passhow"
                        name="password"
                        v-model="password"
                    />
                    <input
                        v-if="passhow"
                        type="text"
                        placeholder="请输入登录密码"
                        name="password"
                        v-model="password"
                    />
                    <i
                        class="iconfont"
                        @click="passhow = !passhow"
                        :class="passhow ? 'icon-xianshi' : 'icon-yincang'"
                    ></i>
                </label>
                <input
                    class="submitbtn"
                    type="button"
                    @click="phonename"
                    value="登录"
                />
            </form>
            <!-- 短信验证码登录 -->
            <form action="" method="POST" v-if="!lang">
                <label class="captcha">
                    <span class="iconfont icon-pic"></span>
                    <input
                        type="text"
                        placeholder="请输入验证码"
                        name="captcha"
                        v-model="captcha"
                    />
                    <img
                        src="http://192.168.1.7:3000/admin/randomcaptcha"
                        alt=""
                        @click="obtainrandom"
                        ref="svgycm"
                    />
                </label>
                <label class="phone">
                    <span class="iconfont icon-tubiao--copy"></span>
                    <input
                        type="text"
                        placeholder="请输入你的手机号"
                        name="phones"
                        v-model="phones"
                    />
                    <button type="button" @click="obtainyzm">
                        获取验证码
                    </button>
                </label>
                <label class="phonecaptcha">
                    <span class="iconfont icon-yaochi"></span>
                    <input
                        type="text"
                        placeholder="请输入手机验证码"
                        name="checkingcode"
                        v-model="checkingcode"
                    />
                </label>
                <input
                    class="submitbtn"
                    type="button"
                    @click="phonecode"
                    value="登录"
                />
            </form>
        </div>
    </div>
</template>

<script>
//这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
//例如：import 《组件名称》 from '《组件路径》';
import { getuserlist } from "../../api/api";
export default {
    //import引入的组件需要注入到对象中才能使用
    components: {},
    data() {
        //这里存放数据
        return {
            captcha: "",
            username: "",
            password: "",
            phones: "", //手机号码
            checkingcode: "", //手机验证码
            userzh: true,
            passhow: false,
        };
    },
    //监听属性 类似于data概念
    computed: {
        lang() {
            return Boolean(JSON.parse(this.$route.params.landing));
        },
        getPcaptcha() {
            return this.$store.state.getPcaptcha;
        },
    },
    //监控data中的数据变化
    watch: {
        lang() {
            window.location.reload();
        },
        getPcaptcha(newvalue) {
            console.log(newvalue);
        },
    },
    //方法集合
    methods: {
        obtainrandom() {
            this.$refs.svgycm.src =
                "http://localhost:3000/admin/randomcaptcha?=" +
                new Date().getTime();
        },
        userlength(e) {
            if (e.target.value.length == 11) {
                return (this.userzh = false);
            }
            return (this.userzh = true);
        },
        async obtainyzm() {
            let phones = this.phones;
            if (phones == "") {
                return alert("手机号不能为空!");
            }
            let checkphones = /^1[3|6|8][0-9]{9}/;
            if (!checkphones.test(phones)) {
                return alert("手机号输入错误!");
            }
            // this.$store.dispatch("actgetPcaptcha", {
            //     url: "/obtainyzm",
            //     parmas: {
            //         phones: phones,
            //     },
            // });
            let result = await getuserlist(
                "/obtainyzm",
                { phones: phones },
                "post"
            );
            console.log(result);
        },
        async phonecode() {
            //使用验证码登录
            let pramas = {
                captcha: this.captcha,
                phones: this.phones,
                checkingcode: this.checkingcode,
            };
            let result = await getuserlist("/checkingyzm", pramas, "post");
            this.$store.commit("settoken", result);
            if (result.token) {
                this.$router.push("/home");
            }
        },
        async phonename() {
            //使用手机号和用户名登陆
            let pramas = {
                captcha: this.captcha,
                password: this.password,
            };
            if (this.userzh) {
                pramas.username = this.username;
            } else {
                pramas.phones = this.username;
            }
            let result = await getuserlist("/userlogin", pramas, "post");
            this.$store.commit("settoken", result);
            if (result.token) {
                this.$router.push("/home");
            }
        },
    },
    //生命周期 - 挂载完成（可以访问DOM元素）
    mounted() {
        this.obtainrandom();
    },
};
</script>
<style lang="less">
.administrator {
    padding: 0rem 1rem;
    .a_header {
        width: 100%;
        height: 4.4rem;
        span {
            font-size: 2rem;
            line-height: 4.4rem;
            color: #aaa;
        }
    }
    .a_content {
        width: 100%;
        h2 {
            font-size: 3.3rem;
            font-weight: 500;
            color: #333;
            margin-top: 3rem;
        }
        .landingmode {
            width: 100%;
            height: 4.4rem;
            margin-top: 3rem;
            display: flex;
            text-align: center;
            font-size: 1.4rem;
            background: #cccccc40;
            li {
                width: 50%;
                height: 4.4rem;
                line-height: 4.4rem;
            }
            .li-active {
                background: orangered;
                color: #fff;
            }
        }
        > form {
            width: 100%;
            display: flex;
            flex-direction: column;
            label {
                position: relative;
                margin-top: 2rem;
                span {
                    position: absolute;
                    top: 0;
                    left: 1rem;
                    font-size: 1.8rem;
                    line-height: 4rem;
                }
                input {
                    width: 100%;
                    height: 4rem;
                    border-bottom: 1px solid #ccc;
                    padding-left: 4rem;
                }
            }
            .captcha {
                display: flex;
                input {
                    width: 80%;
                }
                img {
                    height: 4rem;
                }
            }
            .phone {
                display: flex;
                input {
                    padding-right: 11rem;
                }
                button {
                    width: 40%;
                    padding: 0rem 1rem;
                    border-left: 1px solid #ccc;
                    height: 3rem;
                    background: #fff;
                    color: #aaa;
                }
            }
            .password {
                i {
                    position: absolute;
                    top: 0;
                    right: 1rem;
                    line-height: 4rem;
                    font-size: 2rem;
                }
            }
            .submitbtn {
                width: 100%;
                height: 4rem;
                border-radius: 1rem;
                margin-top: 3rem;
                color: #fff;
                background: orangered;
                font-size: 1.4rem;
            }
        }
    }
}
</style>
