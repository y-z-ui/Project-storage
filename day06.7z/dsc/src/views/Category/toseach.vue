<!-- 头部搜索 -->
<template>
    <div class="tosearch">
        <a
            href=""
            @click.prevent="returnback"
            class="iconfont icon-jiantou3"
        ></a>
        <router-link to="/seach" tag="form">
            <input type="text" />
            <span class="iconfont icon-sousuo2"></span>
        </router-link>
    </div>
</template>

<script>
//这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
//例如：import 《组件名称》 from '《组件路径》';

export default {
    //import引入的组件需要注入到对象中才能使用
    components: {},
    data() {
        //这里存放数据
        return {};
    },
    //监听属性 类似于data概念
    computed: {},
    //监控data中的数据变化
    watch: {},
    //方法集合
    methods: {
        returnback() {
            window.history.back();
            // this.
        },
    },
    beforeCreate() {}, //生命周期 - 创建之前
    //生命周期 - 创建完成（可以访问当前this实例）
    created() {},
    beforeMount() {}, //生命周期 - 挂载之前
    //生命周期 - 挂载完成（可以访问DOM元素）
    mounted() {},
    beforeUpdate() {}, //生命周期 - 更新之前
    updated() {}, //生命周期 - 更新之后
    beforeDestroy() {}, //生命周期 - 销毁之前
    destroyed() {}, //生命周期 - 销毁完成
    activated() {}, //如果页面有keep-alive缓存功能，这个函数会触发
};
</script>
<style lang="less">
.tosearch {
    width: 100%;
    // border-bottom: 1px solid #ccc;
    display: flex;
    padding: 1rem 0;
    a {
        width: 10%;
        font-size: 2.5rem;
        text-decoration: none;
        color: #ccc;
        text-align: center;
    }
    form {
        width: 90%;
        position: relative;

        input {
            width: 98%;
            height: 3rem;
            border: 1px solid #ccc;
            border-radius: 1.5rem;
        }
        span {
            color: #ccc;
            position: absolute;
            top: 0;
            right: 1rem;
            line-height: 3rem;
            width: 3rem;
        }
    }
}
</style>
