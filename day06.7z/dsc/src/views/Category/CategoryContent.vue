<!-- Category的内容展示 -->
<template>
    <div class="categorycontent">
        <div class="categorylist wrapper1">
            <ul class="content" @load.once="jsent">
                <li v-for="(items, index) in listdata" :key="items.cat_id">
                    <p
                        :class="{ c_active: activestatus == items.cat_id }"
                        @click="activeact(items.cat_id, index)"
                    >
                        {{ items.cat_name }}
                    </p>
                </li>
            </ul>
        </div>
        <div class="categorygoods wrapper2">
            <div class="content">
                <img :src="dataimg" alt="" />
                <div v-for="items in goodsdata" :key="items.cat_id">
                    <h3>{{ items.cat_name }}</h3>
                    <ul>
                        <router-link
                            tag="li"
                            :to="
                                '/goodslist/' +
                                    item.cat_id +
                                    '?title=' +
                                    item.cat_name
                            "
                            v-for="item in items.child"
                            :key="item.cat_id"
                        >
                            <img :src="item.touch_icon" alt="" />
                            <p>{{ item.cat_name }}</p>
                        </router-link>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
//这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
//例如：import 《组件名称》 from '《组件路径》';
import BetterScroll from "better-scroll";
export default {
    //import引入的组件需要注入到对象中才能使用
    components: {},
    data() {
        //这里存放数据
        return {
            activestatus: 858,
            dataimg: "",
        };
    },
    //监听属性 类似于data概念
    computed: {
        listdata() {
            return this.$store.state.categorylist;
        },
        goodsdata() {
            return this.$store.state.categorygood;
        },
    },
    //监控data中的数据变化
    watch: {
        listdata() {
            this.dataimg = this.$store.state.categorylist[0].touch_catads;
        },
        goodsdata() {
            this.bs1.refresh();
            this.bs2.refresh();
        },
    },
    //方法集合
    methods: {
        activeact(data, index) {
            this.activestatus = data;
            this.$store.dispatch("actcategorygoods", data);
            this.dataimg = this.$store.state.categorylist[index].touch_catads;
        },
        bs() {
            this.$nextTick(() => {
                this.bs1 = new BetterScroll(".wrapper1", {
                    pullUpLoad: true,
                    scrollbar: false,
                    click: true,
                    pullDownRefresh: true,
                });
                this.bs2 = new BetterScroll(".wrapper2", {
                    pullUpLoad: true,
                    scrollbar: false,
                    click: true,
                    pullDownRefresh: true,
                });
            });
        },
    },
    beforeCreate() {}, //生命周期 - 创建之前
    //生命周期 - 创建完成（可以访问当前this实例）
    created() {},
    beforeMount() {}, //生命周期 - 挂载之前
    //生命周期 - 挂载完成（可以访问DOM元素）
    mounted() {
        this.$store.dispatch("actcategorygoods", 858);
        this.bs();
    },
    beforeUpdate() {}, //生命周期 - 更新之前
    updated() {}, //生命周期 - 更新之后
    beforeDestroy() {}, //生命周期 - 销毁之前
    destroyed() {}, //生命周期 - 销毁完成
    activated() {}, //如果页面有keep-alive缓存功能，这个函数会触发
};
</script>
<style lang="less">
.categorycontent {
    width: 100%;
    height: 100%;
    display: flex;
    box-sizing: border-box;
    padding-bottom: 4.9rem;
    .categorylist {
        width: 25%;
        height: 100%;
        overflow: hidden;
        border-right: 1px solid #ccc;
        box-sizing: border-box;
        padding-bottom: 4.9rem;
        ul {
            width: 100%;
            .c_active {
                color: orangered;
                border-left: 2px solid orangered;
            }
            li {
                text-align: center;
                font-size: 1.3rem;
                color: #999;

                height: 3.8rem;
                p {
                    height: 2rem;
                    line-height: 2rem;
                }
            }
        }
    }
    .categorygoods {
        width: 75%;
        height: 100%;
        overflow: hidden;

        > .content {
            padding: 1rem;
            > img {
                width: 100%;
            }
            > div {
                text-align: center;
                font-size: 1.2rem;
                h3 {
                    line-height: 4rem;
                }
                ul {
                    width: 100%;
                    display: flex;
                    flex-wrap: wrap;

                    align-items: center;

                    li {
                        width: 33%;
                        margin: 1.5rem 0;
                        img {
                            width: 60%;
                        }
                    }
                }
            }
        }
    }
}
</style>
