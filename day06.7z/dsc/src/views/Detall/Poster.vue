<!-- 生成海报界面 -->
<template>
    <div class="poster" @click="hiddenposter">
        <div class="thisposter" @click.stop="">
            <canvas ref="mycanvas"></canvas>
            <!-- <span class="exitposter">
                <i class="iconfont icon-round_delete" @click="hiddenposter"></i>
                <em></em>
            </span>
            <img :src="posterimg[size].img_url" alt="" />
            <h3>{{ postername }}</h3>
            <div class="postermassage">
                <span>{{ posternewprice }}</span
                ><del>{{ posteroldprice }}</del>
            </div>
            <div class="posterewm">
                <img
                    src="../../assets/images/ewm.png"
                    onerror="onerror=null;src='../../assets/images/ewm.png'"
                />
                <span>扫码购买优惠多</span>
            </div> -->
        </div>
        <!-- <ul class="postertips" @click.stop="">
            <li>长按识别图中二维码</li>
            <li @click.stop="replaceimg">
                <i class="iconfont icon-spinner11" ref="rotate"></i>
                &nbsp;点击更换图片
            </li>
        </ul> -->
        <!-- <div class="postercaves">
            <canvas ref="mycanvas"></canvas>
        </div> -->
    </div>
</template>

<script>
//这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
//例如：import 《组件名称》 from '《组件路径》';

export default {
    //import引入的组件需要注入到对象中才能使用
    components: {},
    data() {
        //这里存放数据
        return {
            size: 0,
        };
    },
    //监听属性 类似于data概念
    computed: {
        posterdata() {
            return this.$store.state.posterdata;
        },
    },
    //监控data中的数据变化
    watch: {
        posterdata(newvalue) {
            console.log(newvalue);
        },
    },
    //方法集合
    methods: {
        hiddenposter() {
            this.$emit("exitposter");
        },
        replaceimg() {
            this.$refs.rotate.id = "rotate";
            setTimeout(() => {
                this.size++;
                this.$refs.rotate.id = "";
                if (this.size >= this.posterimg.length) {
                    this.size = 0;
                }
            }, 1500);
        },
        createcanvas() {
            this.$nextTick(() => {
                let wwidth = window.screen.availWidth;
                let wheight = window.screen.availHeight;

                let canvas = this.$refs.mycanvas;
                let ctx = canvas.getContext("2d");
                canvas.width = wwidth * 0.8;
                canvas.height = wheight * 0.7;
                ctx.scale(0.8, 0.8);
                console.log(ctx);
                let image = new Image();
                image.src = this.posterdata.img;
                image.onload = function() {
                    ctx.drawImage(image, 0, 0, wwidth, wheight);
                };
            });
        },
    },
    beforeCreate() {}, //生命周期 - 创建之前
    //生命周期 - 创建完成（可以访问当前this实例）
    created() {},
    beforeMount() {}, //生命周期 - 挂载之前
    //生命周期 - 挂载完成（可以访问DOM元素）
    mounted() {
        this.createcanvas();
        console.log(this.posterdata);
    },
    beforeUpdate() {}, //生命周期 - 更新之前
    updated() {}, //生命周期 - 更新之后
    beforeDestroy() {}, //生命周期 - 销毁之前
    destroyed() {}, //生命周期 - 销毁完成
    activated() {}, //如果页面有keep-alive缓存功能，这个函数会触发
};
</script>
<style lang="less">
.poster {
    width: 100%;
    height: 100vh;
    position: fixed;
    top: 0;
    left: 0;
    z-index: 99;
    background: rgba(0, 0, 0, 0.5);
    // transform: scale();
    .thisposter {
        width: 80%;
        height: 70%;
        position: absolute;
        top: 0;
        left: 0;
        bottom: 0;
        right: 0;
        margin: auto;
        background: #fff;
        .exitposter {
            position: absolute;
            top: -4rem;
            right: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            i {
                color: #ffffff3f;
                font-size: 1.8rem;
            }
            em {
                display: block;
                width: 1px;
                height: 3rem;
                background: #ffffff3f;
            }
        }
        img {
            width: 100%;
        }
        h3 {
            padding: 0rem 1.6rem;
            text-indent: 2em;
            color: #333;
        }
        .postermassage {
            padding: 0rem 1.6rem;
            span {
                color: orangered;
                font-size: 2rem;
            }
            del {
                margin-left: 1.2rem;
                color: #ccc;
            }
        }
        .posterewm {
            display: flex;
            align-items: center;
            img {
                width: 100%;
                margin-left: 1.6rem;
                width: 8rem;
                height: 8rem;
                border: 1px solid;
                line-height: 8rem;
                text-align: center;
            }
            span {
                margin-left: 1.6rem;
            }
        }
    }
    .postertips {
        position: absolute;
        bottom: 4rem;
        left: 0;
        right: 0;
        width: 80%;
        height: 4rem;
        margin: auto;
        background: #fff;
        border-radius: 1.2rem;
        align-items: center;
        justify-content: space-around;
        display: flex;
        li {
            font-size: 1.4rem;
            i {
                display: inline-block;
                width: 2rem;
                height: 2rem;
                text-align: center;
                line-height: 2rem;
            }
        }
    }
    .postercaves {
        width: 100%;
        position: absolute;
        top: 0;
        left: 0;
    }
}
#rotate {
    transform: rotateZ(1080deg);
    transition: all 1.5s linear;
}
</style>
