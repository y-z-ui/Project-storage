<!-- 商品详情页 -->
<template>
    <div class="detall">
        <div class="detall-head">
            <span
                :class="[
                    { iconfont: true },
                    { 'icon-jiantou3': true },
                    { 'detall-navfont': !navshow },
                ]"
                @click="goback"
            ></span>
            <ul class="detall-nav" v-if="navshow">
                <li class="detall-nav-active navtab" @click="scrolltogood">
                    商品
                </li>
                <li class="navtab" @click="scrolltodetall">详情</li>
                <li class="navtab" @click="scrolltoguess">推荐</li>
            </ul>
            <span
                :class="[
                    { iconfont: true },
                    { 'icon-fenxiang': true },
                    { 'detall-navfont': !navshow },
                ]"
                @click="showshare"
            ></span>
        </div>
        <div class="detall-content">
            <div class="detall-box1">
                <div class="detall-swiper">
                    <mt-swipe :auto="4000">
                        <mt-swipe-item
                            v-for="value in gooddetall.gallery_list"
                            :key="value.img_id"
                        >
                            <img :src="value.img_url" alt=""
                        /></mt-swipe-item>
                    </mt-swipe>
                </div>
                <div class="detall-price wp">
                    <i>￥</i><span>{{ parseInt(gooddetall.shop_price) }}</span
                    ><i>.00</i><del>{{ gooddetall.market_price_formated }}</del>
                </div>
                <div class="detall-title wp">{{ gooddetall.goods_name }}</div>
                <ul class="detall-message wp">
                    <li>累计销量&nbsp;{{ gooddetall.sales_volume }}</li>
                    <li>库存{{ gooddetall.goods_number }}</li>
                    <li>
                        {{
                            basicinfo.province_name +
                                "&nbsp;" +
                                basicinfo.city_name
                        }}
                    </li>
                </ul>
            </div>
            <div class="detall-box2 wp">
                <div>
                    <span>赠送积分:&nbsp;</span
                    >{{ gooddetall.give_integral }}&nbsp;积分
                </div>
                <br />
                <br />
                <div>
                    <span>服务:&nbsp;</span
                    >&nbsp;正品保证&nbsp;七天无理由退换&nbsp;闪速配送
                </div>
            </div>
            <div class="detall-box2 wp">
                <div @click="toaddress">
                    <span
                        >送至:&nbsp;{{
                            addrrsssdata[0] + addrrsssdata[1] + addrrsssdata[2]
                        }}</span
                    ><i class="iconfont icon-jiantou2"></i>
                </div>
                <br />
                <div>
                    <span>运费:&nbsp;</span>{{ gooddetall.formated_goods_rate }}
                </div>
            </div>
            <div class="detall-box3 wp" @click="showcountselect">
                <span>已选:&nbsp;</span>&nbsp;{{ goodscount }}&nbsp;个
                <i class="iconfont icon-jiantou2"></i>
            </div>
            <div class="detall-box3 wp">
                <span>买家评论</span>
                <i class="iconfont icon-jiantou2"></i>
            </div>
            <div class="detall-box4 discuss wp">
                <span>网友讨论圈</span>
                <i class="iconfont icon-jiantou2"></i>
            </div>
            <div class="detall-box5 tabnav1 wp" ref="tabnav1">
                <mt-navbar v-model="selected">
                    <mt-tab-item id="good-detall">商品详情</mt-tab-item>
                    <mt-tab-item id="good-specs">规格参数</mt-tab-item>
                </mt-navbar>
                <mt-tab-container v-model="selected">
                    <mt-tab-container-item id="good-detall">
                        <mt-cell v-html="gooddetall.desc_mobile" />
                    </mt-tab-container-item>
                    <mt-tab-container-item id="good-specs">
                        <table class="specs-table" border="1">
                            <tr>
                                <td>商品编号</td>
                                <td>{{ gooddetall.goods_sn }}</td>
                            </tr>
                            <tr>
                                <th colspan="2">主体</th>
                            </tr>
                            <tr>
                                <td>品牌</td>
                                <td></td>
                            </tr>
                            <tr>
                                <td>商品重量</td>
                                <td>{{ gooddetall.goods_weight }}kg</td>
                            </tr>
                            <tr>
                                <td>上架时间</td>
                                <td>{{ gooddetall.add_time_format }}</td>
                            </tr>
                            <tr>
                                <th colspan="2">产品规格</th>
                            </tr>
                            <tr
                                v-for="(value,
                                index) in gooddetall.attr_parameter"
                                :key="index"
                            >
                                <td>{{ value.attr_name }}</td>
                                <td>{{ value.attr_value }}</td>
                            </tr>
                        </table>
                    </mt-tab-container-item>
                </mt-tab-container>
            </div>
            <div class="detall-box6" ref="tabnav2">
                <div class="goodguess">
                    ——————
                    <span>猜你喜欢</span>
                    ——————
                </div>
                <div class="guesscontent">
                    <Recommend
                        :rdata="goodguess"
                        @getrecommend="getrecommend"
                    />
                </div>
            </div>
        </div>
        <div class="detall-floor">
            <ul class="df-iocnfont">
                <li class="iconfont icon-dkw_xiaoxi">
                    <span>客服</span>
                </li>
                <li class="iconfont icon-shoucang1">
                    <span>收藏</span>
                </li>
                <router-link
                    to="/cart"
                    tag="li"
                    class="iconfont icon-gouwuche1"
                >
                    <span>购物车</span>
                    <i>{{ cartcount }}</i>
                    <transition name="add">
                        <em v-if="addshow" class="addnumber"
                            >+{{ goodscount }}</em
                        >
                    </transition>
                </router-link>
            </ul>
            <ul class="df-button">
                <li @click="addcart">加入购物车</li>
                <li>立即购买</li>
            </ul>
        </div>

        <!-- 数量弹窗 -->
        <transition name="count">
            <div class="countselect" v-if="countshow">
                <div class="cs-box">
                    <div class="goodicon">
                        <img :src="gooddetall.goods_thumb" alt="" />
                    </div>
                    <div class="goodtitle">
                        <h3>{{ gooddetall.goods_name }}</h3>
                        <p>{{ gooddetall.shop_price_original }}</p>
                        <span>库存:&nbsp;{{ gooddetall.goods_number }}</span>
                    </div>
                </div>
                <div class="countupdown">
                    <span>数量</span>
                    <form action="javaScript:">
                        <button @click="countdown">
                            -
                        </button>
                        <input type="text" v-model="goodscount" />
                        <button @click="countup">
                            +
                        </button>
                    </form>
                </div>
                <ul class="purchase">
                    <li>立即购买</li>
                    <li @click="addcart">加入购物车</li>
                </ul>
                <i class="iconfont icon-chahao exitcount" @click="exitmask"></i>
            </div>
        </transition>
        <!-- 地址弹窗 -->
        <mt-popup v-model="addressshow" position="bottom" class="addressmask">
            <div id="ads-title">
                <span>所在地区</span>
                <i
                    class="iconfont icon-chahao"
                    @click="addressshow = !addressshow"
                ></i>
            </div>
            <mt-picker
                :slots="slots"
                @change="onaddressChange"
                :visibleItemCount="slotsshow"
            ></mt-picker>
        </mt-popup>
        <!-- 弹窗蒙版 -->
        <div class="mask" v-if="maskshow" @click="exitmask"></div>
        <!-- 加入购物车成功提示弹窗 -->
        <transition name="addcart">
            <div class="addcart-box" v-if="addshow">
                <span>&#10003;</span>
                <p>已加入购物车</p>
            </div>
        </transition>
        <!-- 分享弹窗 -->
        <transition name="share">
            <div class="share" v-if="shareshow">
                <h3>分&nbsp;享</h3>
                <ul class="share-option">
                    <li v-on:click="openonwx" v-if="ifweinxin">
                        <i class="iconfont icon-weixin"></i>
                        <span>在微信中分享</span>
                    </li>
                    <li @click="playposter">
                        <i class="iconfont icon-shengchenghaibao"></i>
                        <span>生存海报</span>
                    </li>
                </ul>
            </div>
        </transition>
        <!-- 在微信中分享 -->
        <Openinwx v-if="openinwxshow" @exitmask="exitmask" />
        <!-- 生成海报 -->
        <Poster v-if="postershow" @exitposter="exitposter" />
    </div>
</template>

<script>
//这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
//例如：import 《组件名称》 from '《组件路径》';
import { isweixin } from "../../utils/Isweixin";
import Poster from "./Poster";
import Openinwx from "./openinwx";
import Recommend from "../Home/components/Recommend";
import city from "@/assets/JSON/City.json";
export default {
    //import引入的组件需要注入到对象中才能使用
    components: { Recommend, Openinwx, Poster },
    data() {
        //这里存放数据
        return {
            postershow: false,
            addshow: false,
            navshow: false,
            shareshow: false,
            openinwxshow: false,
            maskshow: false,
            countshow: false,
            addressshow: false,
            selected: "good-detall",
            slotsshow: 5,
            addrrsssdata: [],
            slots: [
                {
                    flex: 1,
                    values: Object.keys(city),
                    className: "slot1",
                    textAlign: "center",
                    defaultIndex: 0,
                },
                {
                    divider: true,
                    content: "-",
                    className: "slot-separate",
                },
                {
                    flex: 1,
                    values: Object.keys(city["北京"]),
                    className: "slot2",
                    textAlign: "center",
                    defaultIndex: 0,
                },
                { divider: true, content: "-", className: "slot-separate" },
                {
                    flex: 1,
                    values: city["北京"]["北京"],
                    className: "slot3",
                    textAlign: "center",
                    defaultIndex: 0,
                },
            ],
        };
    },
    //监听属性 类似于data概念
    computed: {
        gooddetall: function() {
            return this.$store.state.gooddetalldata;
        },
        basicinfo: function() {
            return this.$store.state.basicinfodata;
        },
        goodguess: function() {
            return this.$store.state.goodguessdata;
        },
        dynamic() {
            return this.$route.params;
        },
        ifweinxin() {
            return isweixin();
        },
        goodscount() {
            return this.$store.state.goodscount;
        },
        cartcount() {
            return this.$store.state.cartcount;
        },
    },
    //监控data中的数据变化
    watch: {
        goodscount() {
            if (this.$store.state.goodscount < 1) {
                this.$store.state.goodscount = 1;
            } else if (
                this.$store.state.goodscount >= this.gooddetall.goods_number
            ) {
                this.$store.state.goodscount = this.gooddetall.goods_number;
            }
        },
        dynamic() {
            window.location.reload();
        },
    },
    //方法集合
    methods: {
        goback() {
            window.history.back();
        },
        getgooddetalldata() {
            this.$store.dispatch("actgooddetalldata", {
                goods_id: this.$route.params.goods_id,
                warehouse_id: 0,
                area_id: 0,
                is_delete: 0,
                is_on_sale: 1,
                is_alone_sale: 1,
            });
        },
        exitmask() {
            this.openinwxshow = this.shareshow = this.countshow = this.maskshow = false;
        },
        showcountselect() {
            this.countshow = this.maskshow = true;
            // this.bgpin();
        },
        countdown() {
            this.$store.state.goodscount--;
        },
        countup() {
            this.$store.state.goodscount++;
        },
        toaddress() {
            this.addressshow = true;
        },
        onaddressChange(picker, values) {
            picker.setSlotValues(1, Object.keys(city[values[0]]));
            picker.setSlotValues(2, city[values[0]][values[1]]);
            this.addrrsssdata = values;
        },
        windowscroll() {
            window.onscroll = () => {
                let dom = document.querySelectorAll(".navtab");
                for (let i = 0; i < dom.length; i++) {
                    dom[i].className = "navtab";
                }
                if (window.pageYOffset > 100) {
                    this.navshow = true;
                    document.querySelector(".detall-head").style.background =
                        "rgba(255,255,255,0.8)";
                } else {
                    this.navshow = false;
                    document.querySelector(".detall-head").style.background =
                        "rgba(0,0,0,0)";
                }
                if (window.pageYOffset >= this.$refs.tabnav2.offsetTop - 62) {
                    if (dom[2]) {
                        dom[2].className = "detall-nav-active navtab";
                    }
                } else if (
                    window.pageYOffset >=
                    this.$refs.tabnav1.offsetTop - 44
                ) {
                    if (dom[1]) {
                        dom[1].className = "detall-nav-active navtab";
                    }
                } else if (
                    window.pageYOffset <
                    this.$refs.tabnav1.offsetTop - 41
                ) {
                    if (dom[0]) {
                        dom[0].className = "detall-nav-active navtab";
                    }
                }
            };
        },
        scrolltogood() {
            let toscroll = window.pageYOffset;
            let time = setInterval(() => {
                if (window.pageYOffset == 0) {
                    clearInterval(time);
                }
                toscroll = toscroll - 40 > 0 ? toscroll - 40 : 0;
                window.scroll(0, toscroll);
            }, 10);
        },
        scrolltodetall() {
            let toscroll = window.pageYOffset;
            let toflag = this.$refs.tabnav1.offsetTop - 41;
            let time = setInterval(() => {
                if (toscroll > toflag) {
                    toscroll = toscroll - 40 > toflag ? toscroll - 40 : toflag;
                    window.scroll(0, toscroll);
                } else if (toscroll < toflag) {
                    toscroll = toscroll + 40 < toflag ? toscroll + 40 : toflag;
                    window.scroll(0, toscroll);
                } else {
                    clearInterval(time);
                }
                this.windowscroll();
            }, 10);
        },
        scrolltoguess() {
            let toscroll = window.pageYOffset;
            let toflag = this.$refs.tabnav2.offsetTop - 60;
            let time = setInterval(() => {
                if (toscroll > toflag) {
                    toscroll = toscroll - 40 > toflag ? toscroll - 40 : toflag;
                    window.scroll(0, toscroll);
                } else if (toscroll < toflag) {
                    toscroll = toscroll + 40 < toflag ? toscroll + 40 : toflag;
                    window.scroll(0, toscroll);
                } else {
                    clearInterval(time);
                }
                this.windowscroll();
            }, 10);
        },
        getrecommend() {
            this.$store.dispatch("actgoodguess", { page: 1, siez: 10 });
        },
        addcart() {
            this.exitmask();
            this.addshow = true;
            setTimeout(() => {
                this.addshow = false;
            }, 50);
            let data = {
                good_id: this.gooddetall.goods_id,
                good_title: this.gooddetall.goods_name,
                good_img: this.gooddetall.goods_thumb,
                good_price: this.gooddetall.shop_price,
                isselected: false,
                value: this.goodscount,
            };
            let shop = {
                ru_id: this.basicinfo.ru_id,
                shop_name: this.basicinfo.shop_name,
                isselected: false,
                goods: [data],
            };
            this.$store.commit("cartstorage", shop);
        },
        showshare() {
            this.maskshow = this.shareshow = true;
        },
        openonwx() {
            this.openinwxshow = true;
        },
        playposter() {
            this.postershow = true;
            this.exitmask();
        },
        exitposter() {
            this.postershow = false;
        },
    },
    beforeCreate() {}, //生命周期 - 创建之前
    //生命周期 - 创建完成（可以访问当前this实例）
    created() {},
    beforeMount() {}, //生命周期 - 挂载之前
    //生命周期 - 挂载完成（可以访问DOM元素）
    mounted() {
        this.getgooddetalldata();
        this.windowscroll();
        this.$store.commit("tocount");
        this.$store.commit("tocartdata");
        window.scroll(0, 0);
    },
    beforeUpdate() {}, //生命周期 - 更新之前
    updated() {}, //生命周期 - 更新之后
    beforeDestroy() {}, //生命周期 - 销毁之前
    destroyed() {
        this.$store.state.goodscount = 1;
    }, //生命周期 - 销毁完成
    activated() {}, //如果页面有keep-alive缓存功能，这个函数会触发
};
</script>
<style lang="less" scopet>
html,
body {
    background: #cccccc2d;
}
.detall {
    width: 100%;
    height: 100%;
    position: relative;
    .detall-head {
        width: 100%;
        height: 4.18rem;
        padding: 0rem 1.2rem;
        position: fixed;
        top: 0;
        left: 0;
        z-index: 99;
        display: flex;
        justify-content: space-between;
        align-items: center;
        .detall-navfont {
            background: rgba(0, 0, 0, 0.2);
        }
        span {
            width: 3rem;
            height: 3rem;
            text-align: center;
            line-height: 3rem;
            border-radius: 50%;
            overflow: hidden;
            font-size: 1.6rem;
        }
        .detall-nav {
            width: 60%;
            display: flex;
            li {
                flex-grow: 1;
                text-align: center;
                font-size: 1.6rem;
                padding: 1rem 0rem;
            }
            .detall-nav-active {
                color: orangered;
                border-bottom: 1px solid orangered;
            }
        }
        .detall-navfont {
            font-size: 1.6rem;
            color: #aaa;
        }
    }
    .detall-content {
        width: 100%;
        padding-bottom: 6rem;
        .detall-box1 {
            background: #fff;
            padding: 1rem 0rem;
            .detall-swiper {
                width: 100%;
                height: 37.5rem;
                .mint-swipe {
                    width: 100%;
                    .mint-swipe-item {
                        width: 100%;
                        img {
                            width: 100%;
                        }
                    }
                }
            }
            .detall-price {
                > i {
                    color: orangered;
                    font-style: normal;
                    font-size: 1.6rem;
                    font-weight: bold;
                }
                span {
                    color: orangered;
                    font-size: 2rem;
                    font-weight: bold;
                }
                del {
                    margin-left: 1rem;
                    color: #aaa;
                    font-size: 1.3rem;
                }
            }
            .detall-title {
                font-size: 1.6rem;
                color: #333;
                // overflow: hidden;
                // display: -webkit-box;
                // -webkit-line-clamp: 2;
                // -webkit-box-orient: vertical;
            }
            .detall-message {
                display: flex;
                font-size: 1.4rem;
                color: #aaa;
                justify-content: space-between;
            }
        }
        .detall-box2 {
            div {
                font-size: 1.4rem;
                span {
                    color: #aaa;
                }
                i {
                    float: right;
                }
            }
        }
        .detall-box3,
        .detall-box4 {
            font-size: 1.4rem;
            span {
                color: #aaa;
            }
            i {
                float: right;
            }
        }
        .detall-box5 {
            .mint-navbar {
                .mint-tab-item {
                    .mint-tab-item-label {
                        font-size: 1.4rem;
                    }
                }
                .is-selected {
                    color: orangered;
                    border-bottom: none;
                    position: relative;
                }
                .is-selected::after {
                    content: "";
                    display: block;
                    height: 0.2rem;
                    width: 5rem;
                    background: orangered;
                    position: absolute;
                    bottom: 0.2rem;
                    left: calc(50% - 2.5rem);
                    z-index: 99;
                }
            }
            .mint-tab-container {
                .mint-cell {
                    img {
                        width: 100%;
                    }
                    .move-remove {
                        display: none;
                    }
                }
                .specs-table {
                    border-collapse: collapse;
                    width: 100%;
                    font-size: 1.2rem;
                    text-align: left;
                    tr {
                        td:first-of-type {
                            width: 30%;
                        }
                        td {
                            padding: 0.6rem 1rem;
                        }
                        th {
                            padding-left: 1rem;
                            padding: 0.6rem 1rem;
                        }
                    }
                }
            }
        }
        .detall-box6 {
            width: 100%;
            padding: 0rem 1rem;
            .goodguess {
                margin: 1.4rem 0rem;
                text-align: center;
                span {
                    font-size: 1.6rem;
                }
            }
        }
    }
    .detall-floor {
        width: 100%;
        height: 5rem;
        position: fixed;
        bottom: 0;
        left: 0;
        display: flex;
        background: #fff;
        z-index: 99;
        ul {
            display: flex;
            li {
                flex-grow: 1;
                text-align: center;
            }
        }
        .df-iocnfont {
            width: 40%;
            li {
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                font-size: 2.2rem;
                position: relative;

                span {
                    font-size: 1.2rem;
                }
                i {
                    width: 1.6rem;
                    height: 1.6rem;
                    line-height: 1.6rem;
                    background: orangered;
                    color: #fff;
                    font-size: 1rem;
                    font-style: normal;
                    border-radius: 50%;
                    position: absolute;
                    top: 0.5rem;
                    right: 1rem;
                }
            }
        }
        .df-button {
            width: 60%;
            li {
                line-height: 5rem;
                color: #fff;
                font-size: 1.6rem;
            }
            li:first-of-type {
                background: #f44;
            }
            li:last-of-type {
                background: #ff976a;
            }
        }
    }
}
.wp {
    width: 100%;
    padding: 1rem 1.2rem;
    margin-top: 1rem;
    background: #fff;
}
.mask {
    width: 100%;
    height: 100vh;
    position: fixed;
    top: 0;
    left: 0;
    background: rgba(0, 0, 0, 0.4);
    z-index: 99;
}
//数量弹窗
.countselect {
    width: 100%;
    height: 20rem;
    background: #fff;
    position: fixed;
    bottom: 0;
    left: 0;
    z-index: 100;
    border-top-left-radius: 1.5rem;
    border-top-right-radius: 1.5rem;
    padding: 1.5rem 1rem 0rem;
    .cs-box {
        width: 100%;
        display: flex;
        .goodicon {
            width: 30%;
            // padding: 1rem;
            img {
                width: 80%;
                border-radius: 1.2rem;
                transform: translateY(-50%);
            }
        }
        .goodtitle {
            width: 70%;
            h3 {
                font-weight: 450;
                height: 5rem;
                font-size: 1.5rem;
                overflow: hidden;
                display: -webkit-box;
                -webkit-line-clamp: 2;
                -webkit-box-orient: vertical;
                color: #333;
                line-height: 2.5rem;
            }
            p {
                color: orangered;
                font-size: 1.8rem;
                line-height: 3rem;
            }
            span {
                color: #aaa;
            }
        }
    }
    .countupdown {
        width: 100%;
        padding-top: 1rem;
        display: flex;
        justify-content: space-between;
        span {
            font-size: 1.6rem;
            color: #aaa;
        }
        form {
            input {
                width: 4rem;
                height: 3rem;
                border-top: 1px solid #eee;
                border-bottom: 1px solid #eee;
                text-align: center;
            }
            button {
                width: 3rem;
                height: 3rem;
                border: 1px solid #eee;
                background: #fff;
            }
            button:disabled {
                background: #ccc;
            }
        }
    }
    .purchase {
        width: 100%;
        position: absolute;
        bottom: 0;
        left: 0;
        display: flex;
        li {
            flex-grow: 1;
            text-align: center;
            padding: 1.5rem;
            color: #fff;
            font-size: 1.4rem;
        }
        li:first-of-type {
            background: #fba534;
        }
        li:last-of-type {
            background: #f92028;
        }
    }
    .exitcount {
        position: absolute;
        top: 0.5rem;
        right: 0.5rem;
        font-size: 1.6rem;
        border: 1px solid #aaa;
        border-radius: 50%;
    }
}
.count-enter,
.count-leave-to {
    opacity: 0;
    transform: translateY(100%);
}
.count-enter-active,
.count-leave-active {
    transition: all 0.5s ease;
}
.addressmask {
    width: 100%;
    height: 60vh;
    border-top-left-radius: 1.5rem;
    border-top-right-radius: 1.5rem;
    background: #fff;
    #ads-title {
        width: 100%;
        padding: 1rem 0rem;
        text-align: center;
        font-size: 1.6rem;
        span {
            font-weight: bold;
        }
        i {
            float: right;
            margin-right: 1rem;
        }
    }
}
.addnumber {
    color: orangered;
    font-size: 1.6rem;
    position: absolute;
    top: 0;
    right: 1rem;
    font-style: normal;
}
.add-leave-to {
    opacity: 0;
    transform: translateY(-3rem);
}
.add-leave-active {
    transition: all 1s ease;
}
.addcart-box {
    width: 12rem;
    height: 12rem;
    position: fixed;
    top: calc(50% - 5rem);
    left: calc(50% - 5rem);
    background: rgba(0, 0, 0, 0.5);
    border-radius: 1.5rem;
    display: flex;
    flex-direction: column;
    justify-content: space-around;
    align-items: center;
    color: #fff;
    span {
        font-size: 6rem;
        font-weight: bold;
    }
    p {
        padding: 0rem 0rem 2rem;
        font-size: 1.5rem;
    }
}
.addcart-leave-to {
    opacity: 0;
}
.addcart-leave-active {
    transition: all 2s linear;
}
.share {
    width: 100%;
    // height: 18rem;
    background: #fff;
    position: fixed;
    bottom: 0;
    left: 0;
    z-index: 99;
    padding: 1rem 1.2rem 4rem;
    h3 {
        font-size: 1.6rem;
        font-weight: 450;
        color: #ccc;
        padding: 1rem 0;
        border-bottom: 1px solid #cccccc30;
    }
    .share-option {
        width: 100%;
        display: flex;
        padding-top: 1.2rem;
        li {
            width: 25%;
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
            i {
                font-size: 4rem;
            }
            span {
                line-height: 3rem;
            }
        }
    }
}
.share-enter,
.share-leave-to {
    opacity: 0;
    transform: translateY(100%);
}
.share-enter-active,
.share-leave-active {
    transition: all 0.5s linear;
}
</style>
