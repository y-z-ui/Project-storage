import Vue from 'vue'
import App from './App.vue'
import LyTab from 'ly-tab'
import Mint from 'mint-ui'
import "mint-ui/lib/style.css"
import router from "./route/router"
import VueAwesomeSwiper from 'vue-awesome-swiper'
import "./styles/swiper-bundle.min.css"
import store from "./store/index"



// import 'default-passive-events' //阻止谷歌默认事件

Vue.use(VueAwesomeSwiper, /* { default options with global component } */ )
Vue.config.productionTip = false
Vue.use(LyTab);
Vue.use(Mint);

new Vue({
  router,
  store,
  render: h => h(App),
}).$mount('#app')