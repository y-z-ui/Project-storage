import Vue from "vue";
import VueRouter from "vue-router";

import Home from "../views/Home/Home.vue";
import Find from "../views/Find/Find.vue";
import Categroy from "../views/Category/Category.vue";
import Cart from "../views/Cart/Cart.vue"
import Mine from "../views/Mine/Mine.vue"

Vue.use(VueRouter)

const originalPush = VueRouter.prototype.push
VueRouter.prototype.push = function push(location) {
    return originalPush.call(this, location).catch(err => err)
}



let routes = [{
    path: "/",
    redirect: "/home"
}, {
    path: "/home",
    component: Home,
    children: [{
        path: "/home",
        redirect: "/home/index"
    }, {
        path: "index",
        component: () => import("../views/Home/HomeChildren/Index.vue") //主页
    }, {
        path: "appliances",
        component: () => import("../views/Home/HomeChildren/Appliances.vue") //家用电器
    }, {
        path: "clothing",
        component: () => import("../views/Home/HomeChildren/Clothing.vue") //男装女装
    }, {
        path: "computer",
        component: () => import("../views/Home/HomeChildren/Computer.vue") //电脑办公
    }, {
        path: "figurt",
        component: () => import("../views/Home/HomeChildren/Figurt.vue") //手机数码
    }, {
        path: "hometextiles",
        component: () => import("../views/Home/HomeChildren/Hometextiles.vue") //家居家纺
    }, {
        path: "makeup",
        component: () => import("../views/Home/HomeChildren/Makeup.vue") //个人美妆
    }, {
        path: "shoebags",
        component: () => import("../views/Home/HomeChildren/Shoebags.vue") //鞋靴箱包
    }]
}, {
    path: "/find",
    component: Find
}, {
    path: "/cart",
    component: Cart
}, {
    path: "/category",
    component: Categroy
}, {
    path: "/mine",
    component: Mine
}, {
    path: "/goodslist/:cat_id",
    component: () => import("../components/goodslist.vue")
}, {
    path: "/goodsdetall/:goods_id",
    component: () => import("../views/Detall/Detall.vue")
}, {
    path: "/seach",
    component: () => import("../views/Seach/seach.vue")
}, {
    path: "/seachlist",
    component: () => import("../views/Seach/seachlist.vue")
}, {
    path: "/administrator/:landing",
    component: () => import("../views/Administrator/administrator.vue")
}];

let router = new VueRouter({
    routes
});
router.beforeEach((to, from, next) => {
    if (to.path == '/administrator/1' || to.path == "/administrator/0") {
        next();
    }
    let token = JSON.parse(localStorage.getItem("unlogin")).token;
    if (!token) {
        next("/administrator/1");
    } else {
        next();
    }
})

export default router