import ajax from "./ajax";


const Base_URL = "/api";
const User_URL = "http://192.168.1.44:3000/admin";

export const getHomeList = (url, params, type) => {
    return ajax(Base_URL + url, params, type)
}
export const gategorylist = () => {
    return ajax(Base_URL + "/catalog/list");
}
export const getegorygoods = (id) => {
    return ajax(Base_URL + "/catalog/list/" + id)
}

export const getuserlist = (url, pramas, type) => {
    console.log(url, pramas)
    return ajax(User_URL + url, pramas, type)
}