<!-- 商品列表 -->
<template>
    <div class="goodslist">
        <div class="goodslisthead">
            <div>
                <Search />
            </div>
            <span
                class="iconfont icon-leimupinleifenleileibie"
                v-if="linestatus"
                @click="tolinestatus"
            >
            </span>
            <span
                class="iconfont icon-icon-viewlist"
                v-else
                @click="tolinestatus"
            ></span>
        </div>
        <ul class="goodslistnav">
            <li class="goodslistnavs glactive">
                综合<span
                    :class="[
                        { iconfont: true },
                        { 'icon-jiantou-copy-copy': !ligslt1 },
                        { 'icon-jiantou': ligslt1 },
                    ]"
                ></span>
            </li>
            <li class="goodslistnavs">新品</li>
            <li class="goodslistnavs">销量</li>
            <li class="goodslistnavs">
                价格<span
                    :class="[
                        { iconfont: true },
                        { 'icon-jiantou-copy-copy': !ligslt2 },
                        { 'icon-jiantou': ligslt2 },
                    ]"
                ></span>
            </li>
            <li @click="screen" class="saxa">
                <span class="iconfont icon-sousuo">筛选</span>
            </li>
        </ul>
        <ul
            :class="[
                { goodslistcontent1: linestatus },
                { goodslistcontent2: true },
            ]"
            v-infinite-scroll="loadMore"
            infinite-scroll-disabled="loading"
            infinite-scroll-distance="10"
        >
            <router-link
                tag="li"
                :to="'/goodsdetall/' + items.goods_id"
                v-for="items in gsltdata"
                :key="items.goods_id"
            >
                <img :src="items.goods_thumb" alt="" />
                <div>
                    <h4>{{ items.goods_name }}</h4>
                    <span>{{ items.shop_price_formated }}</span>
                    <p>
                        <i>进店</i>
                        <span>{{ items.sales_volume + "人已购买" }}</span>
                        <em class="iconfont icon-gouwuche"></em>
                    </p>
                </div>
            </router-link>
        </ul>
        <transition name="mask">
            <div class="xasabox" v-if="xasaboxflag">
                <div class="xasabox1">
                    <h3>自营产品</h3>
                    <div><mt-switch v-model="value"></mt-switch></div>
                </div>

                <div class="xasabox2">
                    <span>近看有货</span><span>促销</span>
                </div>
                <div class="xasabox3">
                    <h3>
                        价格区间
                    </h3>
                    <div>
                        <input
                            type="text"
                            v-model.lazy="min"
                            placeholder="最低价"
                        />
                        <span>——</span>
                        <input
                            type="text"
                            v-model.lazy="max"
                            placeholder="最高价"
                        />
                    </div>
                </div>
                <div class="xasabox4">
                    <h3>品牌</h3>
                    <span class="iconfont icon-jiantou2"></span>
                </div>
                <div class="xasabox5">
                    <div @click="del">关闭</div>
                    <div @click="led">确定</div>
                </div>
            </div>
        </transition>
    </div>
</template>

<script>
//这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
//例如：import 《组件名称》 from '《组件路径》';
import Search from "../views/Category/toseach";
export default {
    //import引入的组件需要注入到对象中才能使用
    components: {
        Search,
    },
    data() {
        //这里存放数据
        return {
            linestatus: false,
            ligslt1: false,
            ligslt2: false,
            xasaboxflag: false,
            value: false,
            size: 10,
            page: 1,
            sort: "goods_id",
            order: "desc",
            min: "",
            max: "",
        };
    },
    //监听属性 类似于data概念
    computed: {
        cat_id() {
            return this.$route.params.cat_id;
        },
        gsltdata() {
            return this.$store.state.goodslistdata;
        },
    },
    //监控data中的数据变化
    watch: {},
    //方法集合
    methods: {
        tolinestatus() {
            this.linestatus = !this.linestatus;
        },
        getdata() {
            this.$store.dispatch("actgoodslist", {
                cat_id: this.cat_id,
                size: this.size,
                page: this.page,
                sort: this.sort,
                order: this.order,
                min: this.min,
                max: this.max,
            });
        },
        screen() {
            //这里写筛选
            this.xasaboxflag = !this.xasaboxflag;
        },
        loadMore() {
            if (this.$store.state.goodslistdata.length) {
                this.page++;
            }
            this.getdata(); //下拉加载
            console.log(this.page);
            this.loading = true;
            setTimeout(() => {
                this.loading = false;
            }, 2500);
        },
        del() {
            this.xasaboxflag = false;
            this.max = this.min = "";
            this.value = false;
            this.$store.commit("togoodslist", []);
            this.getdata();
        },
        led() {
            this.xasaboxflag = false;
            this.$store.commit("togoodslist", []);
            this.getdata();
        },
    },
    beforeCreate() {}, //生命周期 - 创建之前
    //生命周期 - 创建完成（可以访问当前this实例）
    created() {},
    beforeMount() {}, //生命周期 - 挂载之前
    //生命周期 - 挂载完成（可以访问DOM元素）
    mounted() {
        // this.getdata();
        let doc = document.querySelectorAll(".goodslistnavs");
        for (let i = 0; i < doc.length; i++) {
            doc[i].onclick = () => {
                for (var j = 0; j < doc.length; j++) {
                    doc[j].className = "goodslistnavs";
                }
                doc[i].className = "glactive goodslistnavs";
                if (doc[i] == doc[0]) {
                    this.ligslt1 = !this.ligslt1;
                    if (this.ligslt1) {
                        this.sort = "goods_id";
                        this.order = "asc";
                        this.page = 1;
                    } else {
                        this.sort = "goods_id";
                        this.order = "desc";
                        this.page = 1;
                    }
                } else if (doc[i] == doc[1]) {
                    this.sort = "last_update";
                    this.order = "desc";
                    this.page = 1;
                } else if (doc[i] == doc[2]) {
                    this.sort = "sales_volume";
                    this.order = "desc";
                    this.page = 1;
                } else if (doc[i] == doc[3]) {
                    this.ligslt2 = !this.ligslt2;
                    if (this.ligslt2) {
                        this.sort = "shop_price";
                        this.order = "desc";
                        this.page = 1;
                    } else {
                        this.sort = "shop_price";
                        this.order = "asc";
                        this.page = 1;
                    }
                }
                this.$store.commit("togoodslist", []);
                this.getdata();
            };
        }
    },
    beforeUpdate() {}, //生命周期 - 更新之前
    updated() {}, //生命周期 - 更新之后
    beforeDestroy() {
        this.$store.commit("togoodslist", []);
    }, //生命周期 - 销毁之前
    destroyed() {}, //生命周期 - 销毁完成
    activated() {}, //如果页面有keep-alive缓存功能，这个函数会触发
};
</script>
<style lang="less" scoped>
html,
body {
    background: #eee;
}
.goodslist {
    width: 100%;
    .goodslisthead {
        width: 100%;
        display: flex;
        div {
            width: 90%;
            div {
                width: 100%;
            }
        }
        > span {
            text-align: center;
            width: 7%;
            font-size: 2.2rem;
            line-height: 5rem;
        }
        border-bottom: 1px solid #ccc;
    }
    .goodslistnav {
        width: 100%;
        display: flex;
        border-bottom: 1px solid #ccc;
        li {
            width: 25%;
            padding: 1rem 0;
            text-align: center;
            span {
                font-size: 1rem;
            }
        }
        .glactive {
            color: orangered;
        }
    }
    .goodslistcontent2 {
        width: 100%;
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        padding: 1rem;
        > li {
            width: 49%;
            background: #fff;
            margin-top: 1rem;
            > img {
                width: 100%;
                height: 17rem;
            }
            > div {
                padding: 0rem 1.2rem;
                > h4 {
                    margin-top: 0.5rem;
                    font-size: 1.4rem;
                    height: 4rem;
                    line-height: 2rem;
                    font-weight: 500;
                    overflow: hidden;
                    display: -webkit-box;
                    -webkit-line-clamp: 2;
                    -webkit-box-orient: vertical;
                }
                > span {
                    display: inline-block;
                    height: 3rem;
                    line-height: 3rem;
                    font-size: 1.6rem;
                    font-weight: 700;
                    color: orangered;
                }
                > p {
                    width: 100%;
                    > i {
                        font-style: normal;
                        color: orangered;
                        padding: 1px 2px;
                        background: hsla(16, 100%, 50%, 0.15);
                    }
                    > span {
                        margin-left: 0.5rem;
                        color: #ccc;
                    }
                    > em {
                        font-style: normal;
                        float: right;
                    }
                }
            }
        }
    }
    .goodslistcontent1 {
        flex-direction: column !important;
        li {
            width: 100% !important;
            display: flex !important;
            padding: 1rem;
            > img {
                width: 9rem !important;
                height: 9rem !important;
            }
        }
    }
}
.xasabox {
    width: 100%;
    height: 100%;
    position: fixed;
    top: 0;
    left: 0;
    background: #eee;
    z-index: 9999;
    h3 {
        font-size: 1.6rem;
        color: #666;
        font-weight: 500;
    }
    > div {
        background: #fff;
        margin-bottom: 10px;
        padding: 1rem 1.2rem;
    }
    .xasabox1 {
        h3 {
            line-height: 3rem;
        }
        display: flex;
        justify-content: space-between;
    }
    .xasabox2 {
        span {
            font-size: 1.4rem;
            background: #eee;
            padding: 0.4rem 3.4rem;
            margin-right: 1rem;
            color: #666;
        }
    }
    .xasabox3 {
        h3 {
            padding: 0.5rem 0rem 1.4rem;
            border-bottom: 1px solid #eee;
        }
        div {
            display: flex;
            justify-content: space-around;
            align-items: center;
            padding: 1rem 0rem;
            input {
                height: 5rem;
                background: #eee;
                text-align: center;
            }
            span {
                color: #eee;
            }
        }
    }
    .xasabox4 {
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    .xasabox5 {
        padding: 0;
        margin-bottom: 0;
        width: 100%;
        position: absolute;
        bottom: 0;
        left: 0;
        display: flex;

        div {
            width: 50%;
            text-align: center;
            font-size: 1.6rem;
            padding: 1.6rem 0;
        }
        div:last-of-type {
            background: rgba(253, 25, 25, 0.837);
        }
    }
}
.mask-enter,
.mask-leave-to {
    opacity: 0;
    transform: translateX(100%);
}
.mask-enter-active,
.mask-leave-active {
    transition: all 0.5s ease;
}
.mint-switch {
    .mint-switch-input:checked + .mint-switch-core {
        border-color: red;
        background-color: red;
    }
}
</style>
