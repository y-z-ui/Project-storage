<!-- swiper -->
<template>
    <div class="swiper-box">
        <swiper ref="mySwiper" :options="swiperOptions">
            <swiper-slide v-for="(items, index) in maxdata" :key="index">
                <img :src="items.goods_img" alt="" />
                <p>{{ items.title }}</p>
                <span>{{ "￥" + items.shop_price }}</span>
            </swiper-slide>
        </swiper>
    </div>
</template>

<script>
//这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
//例如：import 《组件名称》 from '《组件路径》';

export default {
    //import引入的组件需要注入到对象中才能使用
    components: {},
    data() {
        //这里存放数据
        return {
            swiperOptions: {
                slidesPerView: 3.4,
                // initialSlide: 1,
                spaceBetween: 5,
            },
        };
    },
    props: { maxdata: Array },
    //监听属性 类似于data概念
    computed: {
        swiper() {
            return this.$refs.mySwiper.$swiper;
        },
    },
    //监控data中的数据变化
    watch: {},
    //方法集合
    methods: {},
    beforeCreate() {}, //生命周期 - 创建之前
    //生命周期 - 创建完成（可以访问当前this实例）
    created() {},
    beforeMount() {}, //生命周期 - 挂载之前
    //生命周期 - 挂载完成（可以访问DOM元素）
    mounted() {
        this.swiper.slideTo(3, 1000, false);
    },
    beforeUpdate() {}, //生命周期 - 更新之前
    updated() {}, //生命周期 - 更新之后
    beforeDestroy() {}, //生命周期 - 销毁之前
    destroyed() {}, //生命周期 - 销毁完成
    activated() {}, //如果页面有keep-alive缓存功能，这个函数会触发
};
</script>
<style lang="less">
.swiper-box {
    width: 100%;
    .swiper-slide {
        height: 17.9rem;
        border-radius: 1.5rem;
        overflow: hidden;
        background-color: #fff;
        img {
            width: 100%;
        }
        p {
            height: 4rem;
            overflow: hidden;
            text-overflow: ellipsis;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            padding: 1rem 0.5rem;
            line-height: 1.5rem;
        }
        span {
            padding: 1.5rem 0.5rem;
            line-height: 3rem;
            color: orangered;
        }
    }
}
.swiper-wrapper {
    width: 178%;
}
</style>
