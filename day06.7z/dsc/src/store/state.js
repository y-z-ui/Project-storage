const state = {
    categorylist: [],
    categorygood: [],
    goodslistdata: [],
    gooddetalldata: {},
    basicinfodata: {},
    goodguessdata: [],
    posterdata: {},
    cartdata: "",
    goodscount: 1,
    cartcount: "",
    allchecked: "",
    computcount: "00",
    unlogin: localStorage["unlogin"] ? JSON.parse(localStorage["unlogin"]) : {}
}
export default state;