const mutations = {
    categorylist(state, data) {
        state.categorylist = data;
    },
    tocategorygoods(state, data) {
        state.categorygood = data;
    },
    togoodslist(state, data) {
        state.goodslistdata = data;
    },
    togooddetalldata(state, data) {
        state.gooddetalldata = data;
    },
    tobasicinfodata(state, data) {
        state.basicinfodata = data;
    },
    togoodguess(state, data) {

        state.goodguessdata = data;
    },
    toposterdata(state, data) {
        state.posterdata = data;
    },
    cartstorage(state, data) {
        if (!localStorage.getItem("goods")) {
            localStorage.setItem("goods", JSON.stringify([data]));
        } else {
            let cart = localStorage.getItem("goods");
            cart = JSON.parse(cart);
            let tx = cart.find((items) => {
                return items.ru_id == data.ru_id;
            })
            if (tx) {
                let fx = tx.goods.find((items) => {
                    return items.good_id == data.goods[0].good_id
                })
                if (fx) {
                    fx.value += state.goodscount;
                } else {
                    tx.goods.push(data.goods[0]);
                }
            } else {
                cart.push(data);
            }
            localStorage.setItem("goods", JSON.stringify(cart));
            state.cartcount += state.goodscount
        }
    },
    tocartdata(state) {
        let data = JSON.parse(localStorage.getItem("goods"))
        state.cartdata = data;
    },
    tocount(state) {
        let count = 0;
        let sta = state.cartdata;
        for (let i = 0; i < sta.length; i++) {
            for (let j = 0; j < sta[i].goods.length; j++) {
                count += sta[i].goods[j].value
            }
        }
        state.cartcount = count;
    },
    toallchecked(state) {
        setInterval(() => {
            state.allchecked = JSON.parse(localStorage.getItem("allchecked"))
        }, 10)
    },
    tocomputcount(state) {
        let thesum = 0;
        let count = 0;
        let data = JSON.parse(localStorage.getItem("goods"));
        if (data) {
            for (let i = 0; i < data.length; i++) {
                for (let j = 0; j < data[i].goods.length; j++) {
                    if (data[i].goods[j].isselected) {
                        count += data[i].goods[j].value
                        thesum += (data[i].goods[j].good_price * data[i].goods[j].value)
                    }
                }
            }
            state.computcount = [thesum, count];
        }
    },
    settoken(state, parmas) {
        let token = JSON.stringify(parmas)
        localStorage.setItem("unlogin", token);
        state.unlogin = token;
    }
}

export default mutations;