const getter = {}

export default getter;