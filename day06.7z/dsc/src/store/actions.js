import {
    getHomeList,
    gategorylist,
    getegorygoods,
} from "../api/api"

const actions = {
    async actgoodslist(context, prame) {
        let result = await getHomeList("/catalog/goodslist/", prame, "post");
        if (!context.state.goodslistdata.length) {
            await context.commit("togoodslist", result.data);
        } else {
            let data = [...context.state.goodslistdata];
            data = [...data, ...result.data]
            await context.commit("togoodslist", data)
        }
    },
    async categorylist(context) {
        let result = await gategorylist();
        await context.commit("categorylist", result.data);
    },
    async actcategorygoods(context, id = 858) {
        let result = await getegorygoods(id);

        await context.commit("tocategorygoods", result.data);
    },
    async actgooddetalldata(context, prames) {
        let result = await getHomeList("/goods/show", prames, "post");


        let url = result.data.gallery_list[0].img_original;

        function getBase64(img) {
            var canvas = document.createElement("canvas")
            var ctx = canvas.getContext("2d")
            canvas.width = img.width;
            canvas.height = img.height;
            img.crossOrigin = "Anonymous"
            ctx.drawImage(img, 0, 0, img.width, img.height);
            let ext = url.split(".")[url.split(".").length - 1].toLowerCase();
            var dataURL = canvas.toDataURL("image/" + ext);
            return dataURL
        }

        // function getBase64(img) {
        //     var canvas = document.createElement("canvas")
        //     var ctx = canvas.getContext("2d")
        //     console.log(ctx);
        //     canvas.width = img.width
        //     canvas.height = img.height
        //     img.crossOrigin = "Anonymous"
        //     ctx.drawImage(img, 0, 0, img.width, img.height);
        //     let ext = url.split(".")[url.split(".").length - 1].toLowerCase();
        //     // var ext = img.src.substring(img.src.lastIndexOf(".") + 1).toLowerCase()
        //     var dataUrl = canvas.toDataURL("image/" + ext)
        //     return dataUrl
        // }

        let image = new Image();
        image.src = url;
        image.onload = function () {
            let dataurl = getBase64(image)
            // console.log(dataurl)
            let posterdata = {
                "img": dataurl,
                "title": result.data.goods_name,
                "nowprice": result.data.shop_price_formated,
                "oldprice": result.data.market_price_formated
            }
            console.log(posterdata);
            context.commit("toposterdata", posterdata);
        }

        await context.commit("togooddetalldata", result.data);
        await context.commit("tobasicinfodata", result.data.basic_info);

    },
    async actgoodguess(context, prames) {
        let result = await getHomeList("/goods/goodsguess", prames, "post");

        await context.commit("togoodguess", result.data)
    },
}

export default actions;